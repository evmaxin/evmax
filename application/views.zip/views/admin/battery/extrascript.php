
<script>
    var tab = 1;
    //var target;
   //alert(tab);
   //console.log(tab);
  
   //alert(target);
    // activaTab(tab);
        //  function activaTab(tab){
      $('.nav-tabs a[href="#tab_' + tab + '"]').tab('show');
      // };
        </script>