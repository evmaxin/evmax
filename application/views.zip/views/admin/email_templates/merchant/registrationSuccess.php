<!DOCTYPE html>
<html>
<head>
<title>Registration Successfully</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<style type="text/css">

</style>
<body style="margin: 0 !important; padding: 0 !important; background-color: #fff;" bgcolor="#fff">

<center>

<div  style="padding:520px 0px;;height:1000px;width:707px;background:url('<?php echo base_url();?>images/registrationEmail/Registration_In_process4.png') no-repeat;background-size: 100%;" >
  <h1 style="color: #334e9f;
    font-weight: 900;
    font-size: 65px;
    float: left;
    margin-left: 78px;">#<?php echo $this->session->userdata('registration_id')?></h1>
    
</div>
    </center>
</body>
</html>
