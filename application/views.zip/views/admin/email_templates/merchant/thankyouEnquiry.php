<!DOCTYPE html>
<html>
<head>
<title>Registration Successfully</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<style type="text/css">

</style>
<body style="margin: 0 !important; padding: 0 !important; background-color: #fff;">

<center>

<div  style="margin-top:50px;padding:502px 0px;;height:auto;width:707px;background:url('<?php echo base_url();?>images/registrationEmail/2.png') no-repeat;background-size: 100%;" >
  <h1 style="color: #344e9a;font-weight: 900;font-size: 33px;">EnquiryId :<?php echo $this->session->userdata('enquiry_id1')?></h1>
    
	
</div>
    </center>
</body>
</html>
