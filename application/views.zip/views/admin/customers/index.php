<div class="page-content">
      
      <div class="row">
        <div class="col-md-12">
          <div class="portlet box blue">
            <div class="portlet-title">
              <div class="caption"> <i class="icon-user-follow"></i>Customers</div>
              <div class="tools"> <a href="javascript:;" class="collapse"> </a> </div>
            </div>
            <div class="portlet-body">
              <div class="table-toolbar"> </div>
                 
        <table id="table" class="table table-striped table-hover table-bordered display" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Phone</th>
               
                   <!--  <th>Order history</th>-->
                    
                </tr>
            </thead>
            <tbody>
            </tbody>

           
        </table>
             
            </div>
            
     
          </div>
        </div>
      </div>
    </div>
