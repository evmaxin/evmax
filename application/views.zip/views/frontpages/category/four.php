
  

    <style type="text/css">
      .topHeader{
  border: 1px solid #ccc;
  
}
.borderBlock{
  height:0;
  margin:10px 0;
}
.logo{
  height:100px;
  width:auto;
}
/*img{
  height:40px;
  width:40px;
}*/
.mgcart{
  height: 25px;
    width: 25px;
    
}
.mgcart1{
  position: relative;
    top: 20px;
}
.cart1{
  color:red;
}
.subHeader{
  margin:10px 0;
  font-weight: 500;
  font-size: 17px;
}
.topbar{
  /*border:1px solid;*/
  padding:16px 16px;
  background-color:#eaedef;
  color:#777474;
  margin:0px 0;
}
.searchTxtBox{
  border:1px solid #333;
  height:33px;
}
.searchTxtBox1{
  border:1px solid #333;
  height:28px;
}
.goBtn{
  background-color:black;
  color:#fff;
  text-align: center;
  font-weight: bold;
  padding: 6px;
  margin: -4px;
  border:none;
}
.goBtn1 {
    color: #fff;
    text-align: center;
    font-weight: bold;
    padding: 2px;
    margin: -44px;
    border: none;
    position: relative;
}
.rect{
  height:26px;
  width:26px;
  border:1px solid #ccc;
  
}
.digit{
  font-weight: bold;
  font-size:16px;
  
}
.plus{
  
}
.prodImg{
  height:90px;
  width:90px;
  margin:10px;
}
.mapicon{
  height:30px;
  width:30px;
  
}
.signupBtn, .amntBox, .gstnBox {
  border: 1px solid #ccc;
  padding: 9px;
  width:389px;
}
.coupnCodeBox {
  margin: 10px;
}
.noCostBox {
  font-style: normal;
    color: #14a9cc;
    line-height: 16px;
    text-transform: initial;
    margin: 12px;
    width:326px;
}

.linebar {
  border-top: 1px solid #ccc;
  margin: 11px 28px;
  height: 2px;
}
.linebar2 {
  border-top: 1px solid #ccc;
  margin: -3px  0;
  height: 2px;
}

.sgn{
  color:red;
  font-weight: 700;
    font-size: 17px;
}
.no{
  color: red;
  position:relative;
  
  
  font-weight: bold;
}
.content1{
  width: 343px;
}
.cont1{
  width:220px;
  
  top: 18px;
  font-size: 13px;
  font-weight: bold;
  color:grey;
}
.cont2{
  width: 219px;
  font-size: 12px;
  
  top: -7px;
}
.cont3{
  color:grey;
  font-size:13px;
  font-weight: bold;
  
  top: 32px;
}
.cont4{
  font-size: 12px;
  
  top: 55px;
}
.redln{
  color:red;
  position:relative;
  font-size:12px;
    padding: 6px 1px;
}
.sym{
  position: relative;
  
  height:20px;
  width:20px;
  background: none;
}
.callogo{
  position: relative;
  
  height:20px;
  width:20px;
  background: none;
}
.stamplogo{
  height:20px;
  width:20px;
  background: none;
}
.lgButton {
  background:orange;
  width: 393px;
  margin: 10px 0;
  text-align: center;
  height:42px;
}
.newRect {
  border: 1px solid;
  padding: 5px;
  width: 35px;
  text-align: center;
}
.contamt{
  
  font-size: 12px;
  top: 36px;
}
.lncont{
  
  font-size: 12px;
  top:-13px;
}
.rect2{
  height:26px;
  width:26px;
  
  border:1px solid #ccc;
}
.lstline{
  
}
.gstCont{
  width:289px;
  
  font-size: 9px;
}
.gstCont2{
  
  
  font-size: 9px;
  color:grey;
}
.rect3{
  height:26px;
  width:26px;
  border:1px solid #ccc;
}
.circle{
  height:20px;
  width:20px;
  border-radius: 20px;
  border:1px solid #ccc;
  text-align: center;
}
.quMark{
  
}
.btn{
  position: relative;
  top: 5px;
  left: -6px;
  color: white;
  font-size: 17px;
  font-weight: bold;
}
.freeShip{
  width: 356px;
  color: #888;
  
}
.veh{
  height:30px;
  width:30px;
}
.visa{
  height: 77px;
  width: 143px;
  position: relative;
  
}
.master{
  height: 70px;
  width:120px;
  position: relative;
  
}
.mastero{
  height:70px;
  width:130px;
  
}
.rupay{
  height:70px;
  width:120px;
}
.buy{
  position: relative;
  

}
.we{
  position: relative;
  
}
.safe{
  
}
.cost{
  position: relative;
  
  
}
.sec{
  height:50px;
  width:50px;
  margin:5px;
}
.finalline{
  
}

.cards{
  width:50px;
  height:50px;
  margin:5px;

}
.fntsz{
  font-size: 13px;
}
.Evfour1{
	padding: 6px 9px;
}
.Evfour2{
	position: relative;
    top: -11px;
    left: 50px;
}
.Evfour3{
	position: relative;
	left: 25px;
}
.luvdel{
      position: relative !important;
    top: 22px !important;
}
.cartpg{
  width: 98% !important;
}
.goBtn {
    background-color: black;
    color: #fff;
    text-align: center;
    font-weight: bold;
    padding: 5px;
    margin: -5px;
    border: none;
    position: relative;
}
.cartpg1{
  position: relative;
    left: 31px;
}
.colr2018{
  color: #555 !important;
  font-weight: 600;
      line-height: 19px;
    letter-spacing: -1px;
}
.delivdet{
  padding-left: 24px !important;
}
.delivdet11{
      color: #444;
    letter-spacing: -1px;
    font-weight: 600;
}
.coupncode1{
  font-weight: 700;
    font-size: 16px;
    letter-spacing: 0px;
    color: #333;
}
.A1122{
  float: left;
    font-size: 11px;
    margin-left: 10px;
    margin-top: -7px;
  }
  .totalpay{
    float: right;
    font-weight: bold;
    font-size: 18px;
    position: relative;
    top: -43px;
  }
  .btn {
    position: relative;
    top: -6px;
    left: -6px;
    color: white;
    font-size: 14px;
    font-weight: bold;
}
.banner-wrapper .btn {
    border: solid 0px #3051a0 !important;
}
.txt2{
      padding: 10px;
}
.A11221{
  padding: 10px 4px;
}
.A11222{
  padding: 6px 0px;
}
.A11223{
  height:300px;
   background:#efefef;
  padding: 50px 50px;
}

    </style>
  
    <body style="background-color: #fff;">
      <!--<div class="topHeader container">
        <div class="row">
          <div class="col-md-2"></div>
          <div class="col-md-4">
            <div class="logo">
              <img class=logo src="<?php echo base_url() ?>assets/frontend/img/evlogo.png">
            </div>
          </div>
          <div class="col-md-4 mgcart1">
            <img src="<?php echo base_url() ?>assets/frontend/img/four/cart.png" class="mgcart">
            <div class="text">
              <span class="cart1">Cart</span>... Delivery & Billing Address.... Payment
            </div>
          </div>
          <div class="col-md-2"></div>
        </div>
      </div>-->
      <div class="borderBlock"></div>

      <div class="container" style="overflow: hidden;     padding-bottom: 20px;">
        <div class="row">
          
          <div class="col-md-12 cartpg">
            <div class="subHeader">
              IN YOUR CART <span class="fntsz">(1 Items)</span>
            </div>
            <div class="row">
              <div class="col-md-8" style="border: 1px solid #ccc; padding: 10px;">
                <div class="topbar">
                  <img class="mapicon" src="<?php echo base_url() ?>assets/frontend/img/four/map.png" />
                  Delivery & Assembly Details For Pincode
                  <input class="searchTxtBox cartpg1 txt2" type="text" placeholder="Enter Your Pincode">
                  <input class="goBtn" type="button" value="GO">            
                </div>
                <div class="row ">
                  <div class="col-md-2">
                    <img class="prodImg" src="<?php echo base_url() ?>assets/frontend/img/four/wood1.jpeg">
                  </div>
                  <div class="col-md-5 Evfour1">
                    <div class="colr2018">
                     Sayuri Three Door Shoe Cabinet In Wenge Finish By Mintwud
                    </div>

                    <div class="redln">12 Month's Warranty, 100% Genuine</div>
                    <div>
                      <img class="callogo" src="<?php echo base_url() ?>assets/frontend/img/four/cal.jpg">
                      <span class="delivdet11">
                        Delivery Details</span><br/>
                        <span class="delivdet">Enter Your Pincode Above to Get Details</span>
                      

                    </div>
                    <div class="delivdet11">
                      <img class="stamplogo" src="<?php echo base_url() ?>assets/frontend/img/four/stamp.jpg">
                      COD </div>
                      <span class="delivdet">Available</span>
                    
                  </div>                  
                  <div class="col-md-3 Evfour2">
                    <br>
                    <div class="">
                      <input type="number" id="myNumber" class="newRect">
                    </div><br>
                    <span class="no">
                      Rs. 4,374
                    </span>
                  </div>
                  <div class="col-md-2 luvdel">
                    <span class="sym">
                    <img class=sym src="<?php echo base_url() ?>assets/frontend/img/four/delete.png">
                    <img  src="<?php echo base_url() ?>assets/frontend/img/four/lv.png" class="sym Evfour3">
                  </span>
                  </div>
                </div>
                <div class="linebar"></div>
                <div class="row">
                  <div class="col-md-2">
                    <img class="prodImg" src="<?php echo base_url() ?>assets/frontend/img/four/wood1.jpeg">
                  </div>
                  <div class="col-md-5 Evfour1">
                    <div class="colr2018">
                     Sayuri Three Door Shoe Cabinet In Wenge Finish By Mintwud
                    </div>

                    <div class="redln">12 Month's Warranty, 100% Genuine</div>
                    <div>
                      <img class="callogo" src="<?php echo base_url() ?>assets/frontend/img/four/cal.jpg">
                      <span class="delivdet11">
                        Delivery Details</span><br/>
                        <span class="delivdet">Enter Your Pincode Above to Get Details</span>
                      

                    </div>
                    <div class="delivdet11">
                      <img class="stamplogo" src="<?php echo base_url() ?>assets/frontend/img/four/stamp.jpg">
                      COD </div>
                      <span class="delivdet">Available</span>
                    
                  </div>                  
                  <div class="col-md-3 Evfour2">
                    <br>
                    <div class="">
                      <input type="number" id="myNumber" class="newRect">
                    </div><br>
                    <span class="no">
                      Rs. 4,374
                    </span>
                  </div>
                  <div class="col-md-2 luvdel">
                    <span class="sym">
                    <img class=sym src="<?php echo base_url() ?>assets/frontend/img/four/delete.png">
                    <img  src="<?php echo base_url() ?>assets/frontend/img/four/lv.png" class="sym Evfour3">
                  </span>
                  </div>
                </div>
                <div class="linebar"></div>
                <div class="row">
                  <div class="col-md-2">
                    <img class="prodImg" src="<?php echo base_url() ?>assets/frontend/img/four/wood1.jpeg">
                  </div>
                  <div class="col-md-5 Evfour1">
                    <div class="colr2018">
                     Sayuri Three Door Shoe Cabinet In Wenge Finish By Mintwud
                    </div>

                    <div class="redln">12 Month's Warranty, 100% Genuine</div>
                    <div>
                      <img class="callogo" src="<?php echo base_url() ?>assets/frontend/img/four/cal.jpg">
                      <span class="delivdet11">
                        Delivery Details</span><br/>
                        <span class="delivdet">Enter Your Pincode Above to Get Details</span>
                      

                    </div>
                    <div class="delivdet11">
                      <img class="stamplogo" src="<?php echo base_url() ?>assets/frontend/img/four/stamp.jpg">
                      COD </div>
                      <span class="delivdet">Available</span>
                    
                  </div>                  
                  <div class="col-md-3 Evfour2">
                    <br>
                    <div class="">
                      <input type="number" id="myNumber" class="newRect">
                    </div><br>
                    <span class="no">
                      Rs. 4,374
                    </span>
                  </div>
                  <div class="col-md-2 luvdel">
                    <span class="sym">
                    <img class=sym src="<?php echo base_url() ?>assets/frontend/img/four/delete.png">
                    <img  src="<?php echo base_url() ?>assets/frontend/img/four/lv.png" class="sym Evfour3">
                  </span>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="signupBtn">
                  <span class="sgn">SIGN IN |</span> <span class="
                  coupncode1">SIGN UP</span>
                  <div style="margin-top: 5px;">
                    For Express Checkout, Exciting Offers & More.
                  </div>
                </div>
                <div class="coupnCodeBox">
                  <div class="coupncode1 ">Have a coupon code?</div>

                  <input class="searchTxtBox1 txt2" type="text" placeholder="Enter Coupon Code ">
                  <input class="goBtn1" type="button" value="APPLY " style="background:orange;">
                </div>
                <div class="amntBox">
                  <div style="float: left;">
                    <div class="rect2"></div>
                  </div>
                  <div class="A1122">
                    Contibute Rs.35 To Plant A Tree Through Grow Tree.
                    <div class="linebar2"></div>
                    Note: Evmax Will Match This Amount.
                  </div>
                  <DIV style="clear: both;"></DIV>
                  <div class="A11221">
                  <div style="float:left">Item Total</div>
                  <div style="float:right; font-weight:bold;">Rs. 4,374</div>
                  <DIV style="clear:both"></DIV>
                  <div class="A11222">
                  <div style="float:left">Shipping & Handling<span style="color:red"> (Free)</span></div>
                  <div style="float:right; font-weight:bold;">0</div>
                  </div>
                  </div>
                  <div style="clear:both"></div>
                  <div class="linebar"></div>
                  <div style="float:left; font-weight:bold; font-size: 18px;">You Pay</div></br>
                  <div class="lstline">(inclusive of all taxes)</div>
                  <div class="totalpay">Rs. 4,374</div>
                  <div style="clear:both"></div>                
                </div>
                <div class="noCostBox">
                  No Cost EMI available. EMI starting Rs.208/month
                </div>
                <div class="gstnBox">
                  <div style="float: left; margin:5px;">
                    <div class="rect3">
                    </div>
                  </div>
                  <div style="float: left; margin:5px;">
                    <div class="gstCont">
                      Use <span style="font-weight:bold;">GSTIN</span> For Business Purchase (Optional)
                    </div>
                    <div class="gstCont2">Claim Tax Credit By Entering Your Companies GSTIN</div>
                  </div>
                  <div style="float: left; margin:5px;">
                    <div class="circle">?</div>
                  </div>
                  <div style="clear:both;">
                  </div>
                </div>
                <div class="lgButton">
                  <div class="btn">PLACE ORDER</div>
                </div>
                <div class="freeShip">
                  <img class="veh" src="<?php echo base_url() ?>assets/frontend/img/four/veh.png">
                  Free Shipping For This Order On Online Payment.
                </div>                
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div class="row A11223"> 
          <div class="col-lg-4 col-md-4 col-sm-2">
            <div style="margin-bottom:5px;">
                    WE ACCEPT
                  </div>
                  <div>
                    <img class="cards" src="<?php echo base_url() ?>assets/frontend/img/four/visa.jpg" />
                    <img class="cards" src="<?php echo base_url() ?>assets/frontend/img/four/mast.png" />
                    <img class="cards" src="<?php echo base_url() ?>assets/frontend/img/four/master.png" />
                    <img class="cards" src="<?php echo base_url() ?>assets/frontend/img/four/ru.jpg" />
                  </div>
          </div>

          <div class="col-lg-4 col-md-4 col-sm-2">
            <div style="margin-bottom:5px;">
                    BUY SAFE,PAY EASY
            </div>
            <div>
                    No Cost EMIs: Now pay in easy installments at no additional cost
            </div>
          </div> 

          <div class="col-lg-4 col-md-4 col-sm-2">
            <div style="margin-bottom:5px;">
                    100% SAFE & SECURE
                  </div>
            <div>
              <img class="sec" src="<?php echo base_url() ?>assets/frontend/img/four/sec.png"/>
              <img class="sec" src="<?php echo base_url() ?>assets/frontend/img/four/safe.png"/>
          </div>
      </div>      
            
            
        </div>
        
      </div>
      
  </body>
