<style type="text/css">
   .main-menu-block{
   }
   .upperblockmenu  ul li a{
   position: relative;
   margin-left: 10px;
   }
   ul li{
   list-style: none;
   }
   .department-menu{
   display: none;
   }
   .main-menu-block ul li{
   float: left;
   margin-right: 25px;
   /* margin-left: 1px; */
   margin-top: 30px;
   }
   .upperblock ul li{
   float: left;
   }
   .downcon{
   float: left;
   }
   .downcon img{
   width: 30px;
   height: 30px;
   }
   .downconsearch img{
   margin-left: -30px;
   }
   .searchbar{
   width: 200px;
   height: 30px;
   border-radius: 5%;
   background-color: lightgray;
   border: 1px solid  gray;
   }
   /*.............for slider-............*/
   .slide-mask {
   margin-top: 30px;
   position: relative;
   overflow: hidden;
   height: 500px;
   margin-left: -74px;
   }
   .slide-group {
   position: absolute; 
   top: 0px; 
   left: 10px;
   width: 100%;
   height: 500px;
   }
   .slide {
   height: 500px;
   }
   .slide img{
   width: 100%;
   height: 500px;
   }
   ul li{
   list-style: none;
   }
   /* nav
   ----------------------*/
   .slide-nav {
   text-align: center;
   margin-top: 30px;
   }
   .slide-nav ul {
   margin: 0;
   padding: 0;
   position: relative;
   }
   .slide-nav li {
   float: left;
   display: inline-block;
   list-style: none;
   width: 100px;
   height: 100px;
   position: relative;
   bottom: 10px;
   margin-left: .5em;
   }
   .slide-nav li.current {
   border-left: 5px solid green;
   }
   .bullet1 img{
   width: 100px;
   height: 100px;
   }
   .bullet1{
   border: 1px solid;
   z-index: 1;
   box-shadow: 1px 1px 1px 1px grey;
   margin: 4px;
   }
   /*...............*/
   .productNameTitle{
   background-color: #5cbb59;
   width: 100%;
   height: 50px;
   margin-top:10px;
   text-align: center;
   font-size: 20px;
   color: #fff;
   }
   .productNameTitle h3{
   margin-top: 20px;
   }
   .offp{
   color: #0f0f63;
   font-weight: bold;
   font-size: 25px;
   }
   .detailitem{
   width: 100%;
   height: 50px;
   margin-top: 10px;
   position: relative;
   }
   .detailitem1{
   position: relative;
   float: left;
   }
   .detailitem2{
   margin-left:170px;
   position: relative;
   float: left;
   }
   .offerclass img{
   width: 100px;
   height: 130px;
   margin-top: 15px;
   }
   .offerprice{
   margin-top:10px;
   position: relative;
   width: 100%;
   height: 35px;
   border-bottom: 1px dotted lightgray;
   }
   .ofp{
   left: 16px;
   position: relative;
   }
   .ofp1{
   left: 120px;
   position: relative;
   }
   .totalsave{
   margin-top: 10px;
   width: 100%;
   height: 80px;
   position: relative;
   border-bottom: 1px dotted lightgray;
   }
   .tsave1{
   position: relative;
   float: left;
   }
   .tsave2{
   float: left;
   margin-left: 20px;
   }
   .warranty{
   clear: both;
   margin-bottom: 10px;
   margin-top: 10px;
   }
   .deliverylocation{
   position: relative;
   width: 100%;
   height: 90px;
   background-color: #5cbb59;
   }
   .gobuttonmain input{
   width: 300px;
   height: 30px;
   background-color: #fff;
   position: relative;
   float: left;
   text-align: center;
   }
   .gobutton{
   background-color: #0d0d75;
   position: relative;
   float: left;
   width:30px;
   height:30px;
   color: white;
   text-align: center;
   padding: 3px;
   }
   .gobuttonmain{
   position: relative;
   top: 20px;
   left: 20px;
   }
   .adtoc{
   margin-top: 10px;
   position: relative;
   left: 400px;
   }
   .adtc{
   background-color: #14175d;
   width: 100px;
   height: 50px;
   color: #fff;
   }
   .wish{
   left: 400px;
   top: 10px;
   /* float: left; */
   position: relative;
   right: 10px;
   margin-bottom: 10px;
   }
   .ofp{
   left: 16px;
   font-size: 20px;
   color: #3114a2;
   position: relative;
   }
   .op{
   margin-left: 10px;
   }	
   .easyen{
   position: relative;
   width: 100%;
   height: 30px;
   background-color: #fbfb90;
   font-size: 13px;
   margin-top:10px;
   border:1px solid #e9f22b;
   }
   .easyendata{
   position: relative;
   margin-top: 2px;left:30px;
   }
   .more1{
   position: relative;
   float: left;
   margin-left: 0px;
   }
   .more2{
   position: relative;
   float: left;
   margin-left: 20px;
   }
   .moreone{
   margin-top:10px;
   }
   .morebtn1, .morebtn2{
   width:200px;
   padding: 5px;
   background-color: #fff;
   border:1px solid gray;
   }
   .morebtn1:hover ,.morebtn2:hover{
   background-color: #f2ebeb;
   }
   .social-small{
   clear: both;
   margin-left: 70px;
   }
   .social-circle{
   position: relative;
   margin-top:10px;
   float: left;
   width: 30px;
   height: 30px;
   border-radius: 50%;
   border: 1px solid gray;
   margin-left: 10px;
   }
   .social-circle i{
   position: relative;left:10px;top:2px;
   }
   .social-small .social-circle:hover{
   background-color: #f2ebeb;
   }
   .productDescription1{
   height: 350px;
   margin-top:10px;
   padding: 10px;
   border-top:1px solid gray;
   border-right:1px solid gray;
   border-bottom:1px solid gray;
   }
   .productDescription2{
   height: 350px;
   margin-top:10px;
   padding: 10px;
   border-top:1px solid gray;
   border-left:1px solid gray;
   border-bottom:1px solid gray;
   }
   .detailsproduct{
   margin:auto;
   margin-left: 150px;
   margin-bottom: 20px;
   }
   .paragraph1{
   margin:5px;
   }
   .similarproduct1{
   height: 60px;
   color: #fff;
   background-color: #0e0e6f;
   position: relative;
   margin-top: 20px;
   }
   .similarhead{
   margin-left:500px;
   }
   .yourchoice{
   margin-left: 500px;
   }
   /*product-row css from   */
   .contentproduct{
   margin:10px;
   }
   .b {
   border: 1px solid gray;
   box-shadow: 2px 2px 2px 1px gray;
   }
   .b1:hover {
   content: "kkkk";
   opacity: transparent;
   background-color: gray;
   }
   .card-body {
   color: black;
   }
   .nameveh{
   margin-left: 14px;
   margin-top: 10px;
   }
   .soldby{
   margin-left: 14px;
   margin-top: 10px;
   font-size: 15px;
   }
   .card-body h4 {
   }
   .card-price{
   margin-left: 14px;
   margin-top: 10px;
   margin-bottom: 10px;
   }
   .card-body .btn {
   margin-left: 70px;
   margin-bottom: 5px;
   }
   .breakspace {
   width: 100%;
   height: 20px;
   }
   .originalprice{
   position: relative;
   left:6%;
   color: gray;
   }
   .tab-content{
   width: 100%;
   margin: 0;
   padding: 0;
   }
   .overlay {
   position: absolute;
   bottom: 100%;
   left: 15px;
   right: 0;
   background-color: #50a94863;
   overflow: hidden;
   width: 90%;
   height: 0;
   transition: .5s ease;
   }
   .card:hover .overlay {
   bottom: 0;
   height: 100%;
   }
   .text1 {
   border: 2px solid #10106f;
   /* width: 100px; */
   width: 150px;
   height: 45px;
   /* height: 40px; */
   padding-top: 10px;
   color: white;
   font-weight: bold;
   font-size: 18px;
   padding-top: 9px;
   position: absolute;
   top: 95%;
   left: 28%;
   background-color: #07078a;
   -webkit-transform: translate(-50%, -50%);
   -ms-transform: translate(-50%, -50%);
   transform: translate(-50%, -50%);
   text-align: center;
   color:white;
   }
   .text2 {
   border: 2px solid #10106f;
   /* width: 100px; */
   width: 110px;
   height: 45px;
   /* height: 40px; */
   padding-top: 10px;
   color: white;
   font-weight: bold;
   font-size: 18px;
   padding-top: 9px;
   position: absolute;
   top: 95%;
   left: 80%;
   background-color: #07078a;
   -webkit-transform: translate(-50%, -50%);
   -ms-transform: translate(-50%, -50%);
   transform: translate(-50%, -50%);
   text-align: center;
   color:white;
   }
   .text1 a, .text2 a{
   color: white;
   }
   .priceitem{
   position: relative;
   left: 26%;
   }
   .actualprice{
   position: relative;
   font-weight: bold;
   }
   .mclr1{
   margin-top: 5px;
   margin-left: 10px;
   }
   /*............Popup....................*/
   #viewmore{
   display: none;
   z-index: 10000;
   position: absolute;
   background-color: #fff;
   }
   .bul{
   	clear: both;
   }
   .cancle{
   	width: 30px;
    height: 30px;
    float: left;
    position: relative;
    left: 50px;
   }
   .containerBox{
	box-shadow: 0px 1px  1px 1px grey;
	margin-top: 10px;
}
.sco{
	height: 389px;
    width: 351px;
    margin-left: 63px;
}

.smlSco{
	width: 150px;
    height: 120px;
	
}
.rightArrow{
	height:30px;
	width:30px;
	font-size:35px;
	font-weight: bold;
	float:right;
	margin-top:200px;
	color:gray;
}
.leftArrow{
	height:30px;
	width:30px;
	font-size: 35px;
	font-weight:bold;
	float: left;
	color:gray;
	margin-top: 200px;
}
.select{
	border:3px solid green;
}
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Hide the images by default */
.mySlides {
    display: none;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  margin-top: -22px;
  padding: 16px;
  color: blue;
  font-weight: bold;
  font-size: 25px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: green;
  color: white;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */


.active, .bullet2:hover {
   border-right:5px solid green;
}
.bullet2 img{
   width: 125px;
   height: 120px;
}
/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}
.bullet2{
   margin-top:10px;
  float: right !important;
    width: 128px !important;
    height: 120px !important;
}
/*...........easypopup.....................*/
#easyhidedata{
   display: none;
   z-index: 2000;
   position: absolute;
   background-color: white;
   box-shadow: 1px 1px 1px 1px gray;
}
.smlContainer{
   height: 400px;
   overflow: scroll;
   overflow-x: hidden;
}

.closebtn{
   color:green;
   border: blue;
}
.row1{
   position: fixed;
   background-color: white;
}
.ameExp,.axisbank,.citibank,.hdfc,.hsbc,.icici{
         height: 80px;
         width: 80px;
         margin-top: 14px;
         position: relative;
         top: 15px;
      }
      
      .mon1{
         margin-left: 119px;
         margin-right:20px;
      }
      .mon2{
         margin-left: 8px;
         margin-right: 20px;

      }
      .mon3{
         margin-right: 20px;

      }
      .mon4{
         margin-right: 20px;

      }
      .mon5{
         margin-right: 20px;

      }
      .mon6{
         margin-right: 20px;

      }
      .rect{
         height: 85px;
          width: 80px;
          border: 2px solid green;
          font-size:13px;

      }
      .rect1{
         
          margin-left: 98px;
          margin-top: -66px;

      }
      .rect2{
         
         margin-left: 196px;
         margin-top: -84px;
      }
      .rect3{
         border: none !important;
         margin-left: 286px;
         margin-top: -84px
      }
      .rect4{
         border: none !important;
         margin-left: 377px;
         margin-top: -84px;

      }
      .rect5{
         border: none !important;
         margin-left: 467px;
         margin-top: -84px;
      }
      .rect6{
         border: none !important;
         margin-left: 558px;
         margin-top: -85px
      }
      .cont1{
         margin: 5px;
      }
      .cont2{
         margin: 0px;
      }
      .cont3{
         color:blue;
         margin-top:-4px;
         width:80px;
      }
      .cont4{
         margin:5px;
         font-size: 10px;
      }




   /*......RESPONSIVE.........*/
   @media only screen and (max-width: 1024px) {
   .detailitem2 {
   margin-left: 94px;
   position: relative;
   float: left;
   }
   .gobuttonmain {
   left: 7px;
   }
   .easyen{
   height: 48px;
   }
   .easyendata {
   left: 0px;
   }
   .adtoc {
   left: 353px;
   }
   .wish{
   left:347px;
   }
   .similarhead {
   margin-left: 395px;
   }
   .yourchoice {
   margin-left: 428px;
   }
   }
   @media only screen and (max-width: 768px) {
   .detailitem1{
   margin-left: -28px;
   }
   .detailitem2 {
   margin-left: 13px;
   }
   .deliverylocation {
   height: 107px;
   }
   .adtoc {
   left: 246px;
   }
   .wish{
   left:240px;
   }
   .more2 {
   position: relative;
   float: left;
   top: -36px;
   margin-left: 210px;
   }
   .col-sm-7 {
   width: 195px;
   }
   .productDescription1{
   height: 430px;
   }
   .productDescription2{
   height: 430px;
   }
   .similarhead {
   margin-left: 300px;
   }
   .yourchoice {
   margin-left: 300px;
   }
   }
   @media only screen and (max-width: 425px) {
   .slide-mask {
   /* margin-top: -294px; */
   position: relative;
   overflow: hidden;
   height: 400px;
   width: 100% !important;
   /* margin-left: 0px; */
   top: -504px;
   left:66px;
   /* left: -100px; */
   }
   .slide-nav {
   text-align: center;
   margin-top: 400px;
   margin-left: 30px;
   }
   .slide-group {
   position: absolute;
   top: 0px;
   /* left: 10px; */
   width: 100%;
   height: 400px;
   }
   .detailitem {
   margin-left: 56px;
   width: 100%;
   height: 50px;
   margin-top: -400px;
   position: relative;
   }
   .offerclass{
   position: relative;
   left: 174px;
   }
   .gobuttonmain input {
   width: 225px;
   }
   .adtoc {
   left: 191px;
   }
   .wish{
   left:180px;
   }
   .more2 {
   position: relative;
   float: left;
   top: 0px;
   margin-top: 4px;
   margin-left: 0px;
   }
   .col-sm-4{
   position: relative;
   float: left;
   margin-left: -20px;
   }
   .col-sm-1{
   display: none;
   }
   .col-sm-7 {
   position: relative;
   float: left;
   width: 150px;
   }
   .similarhead {
   margin-left: 129px;
   }
   .yourchoice {
   margin-left: 178px;
   }
   .slide-nav li {
   float: left;
   display: inline-block;
   list-style: none;
   width: 121px;
   height: 120px;
   position: relative;
   bottom: 10px;
   margin-left: .5em;
   }
   }
</style>
</head>
<body>
   <div class="container">
      <div class="row">
         <div class="productNameTitle">
            <h3> Tvs-motors</h3>
         </div>
      </div>
      <div class="container containerBox" id="viewmore">
         
            <div class="slide-wrap row">
               
               <div class="slide-mask col-sm-8 slideshow-container">
                  <ul class="slide-group">
                     <li class="slide mySlides " id="viewclear"><img  src="<?php echo base_url() ?>assets/frontend/img/three/y1.jpg"/></li>
                     <li class="slide mySlides "><img src="<?php echo base_url() ?>assets/frontend/img/three/y2.jpg"/></li>
                     <li class="slide mySlides "><img src="<?php echo base_url() ?>assets/frontend/img/three/y4.jpg"/></li>
                     <li class="slide mySlides "><img src="<?php echo base_url() ?>assets/frontend/img/three/y5.jpg"/></li>
                  </ul>
                  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                   <a class="next" onclick="plusSlides(1)">&#10095;</a>
               </div>
               <div class="slide-nav col-sm-3">
                  <ul>
                     <li class=" bullet2 " onclick="currentSlide(1)"><img src="<?php echo base_url() ?>assets/frontend/img/three/y1.jpg"/></li>
                     <li class=" bullet2 " onclick="currentSlide(2)"><img src="<?php echo base_url() ?>assets/frontend/img/three/y2.jpg"/></li>
                     <li class=" bullet2 " onclick="currentSlide(3)"><img src="<?php echo base_url() ?>assets/frontend/img/three/y4.jpg"/></li>
                     <li class=" bullet2 " onclick="currentSlide(4)"><img src="<?php echo base_url() ?>assets/frontend/img/three/y5.jpg"/></li>
                  </ul>
               </div>
               <div class="col-xs-1">
               <img class="cancle" onclick="cancleFunction()" src="<?php echo base_url() ?>assets/frontend/img/three/cancel.jpg"/>
            </div>
            </div>
         
      </div>
      <div class="row">
         <div class="col-sm-6">
            <div class="slide-wrap row">
               <div class="slide-nav col-sm-4">
                  <ul>
                     <li class="bullet1"><img src="<?php echo base_url() ?>assets/frontend/img/three/y1.jpg"/></li>
                     <li class="bullet1"><img src="<?php echo base_url() ?>assets/frontend/img/three/y2.jpg"/></li>
                     <li class="bullet1"><img src="<?php echo base_url() ?>assets/frontend/img/three/y4.jpg"/></li>
                     <li class="bullet1"><img src="<?php echo base_url() ?>assets/frontend/img/three/y5.jpg"/></li>
                  </ul>
               </div>
               <div class="slide-mask col-sm-8">
                  <ul class="slide-group">
                     <li class="slide" id="viewclear"><img onclick="myFunction()" src="<?php echo base_url() ?>assets/frontend/img/three/y1.jpg"/></li>
                     <li class="slide"><img src="<?php echo base_url() ?>assets/frontend/img/three/y2.jpg"/></li>
                     <li class="slide"><img src="<?php echo base_url() ?>assets/frontend/img/three/y4.jpg"/></li>
                     <img src="<?php echo base_url() ?>assets/frontend/img/three/y5.jpg"/></li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="col-sm-6">
            <div class="detailitem">
               <div class="detailitem1"> <small>MRP</small> <strike> &#x20A8;120000.00</strike><span>incl. of all taxes</span><br>
                  <b class="">OUR PRICE</b> <b class="op"> &#x20A8;100000.00</b>
               </div>
               <div class="detailitem2">
                  Viewed 8564 Times <br>
                  Last Bought: 3 days ago
               </div>
            </div>
            <div class="offerclass">
               <img src="<?php echo base_url() ?>assets/frontend/img/three/offer.gif"/>
            </div>
            <div class="offerprice">
               <b class="offp">Offer price</b>&emsp;<b class="ofp"> &#x20A8;. 80000.00</b> 
               <t class="ofp1">Free shipping</t>
            </div>
            <div class="totalsave">
               <div class="tsave1">Your total Saving</div>
               <div class="tsave2">
                  <t>&#x20A8; 20000.00</t>
                  <br>
                  <t style="border-bottom: 1px solid;">&#x20A8; 20000.00</t>
                  <br>
                  <t>&#x20A8;40000.00</t>
               </div>
            </div>
            <div class="warranty">
               36 Months' Warranty, 100% Genuine, Easy Returns
            </div>
            <div class="deliverylocation">
               <div class="gobuttonmain">
                  <b>Enter Your Pincode To Know Delivery & Assembly Details For Your Location</b>
                  <input type="number" name="location-pin" placeholder="EnterPincode">
                  <div class="gobutton">GO</div>
               </div>
            </div>
            <div class="adtoc">
               <button class="adtc">Add To Cart</button>
            </div>
            <div class="wish">
               <a href="#">Add to Wishlist &#9829;</a>
            </div>
            <div class="" onclick="myEasyFunction()">
               <p  class="easyendata">Buy Easy Installments , as low as &#x20A8;.1000 per month no cost EMI are available</p>
            </div>
            <div class="container">
                 <!-- Trigger the modal with a button -->
                 <p  class="easyen" data-toggle="modal" data-target="#myModal">Buy Easy Installments , as low as &#x20A8;.1000 per month no cost EMI are available</p>

                 <!-- Modal -->
                 <div class="modal fade" id="myModal" role="dialog">
                   <div class="modal-dialog">
                   
                     <!-- Modal content-->
                     <div class="modal-content">
                       <div class="modal-header">
                       </div>
                       <div class="modal-body">
                         <div class="container">
                              <div class="smlContainer">
                              <div class="row1">
                                    <span class="mon1">3 Months</span>
                                    <span class="mon2">6 Months</span>
                                    <span class="mon3">9 Months</span>
                                    <span class="mon4">12 Months</span>
                                    <span class="mon5">18 Months</span>
                                    <span class="mon6">24 Months</span>
                              </div>
                                 <div class="row2">
                                    <img class="ameExp" src="<?php echo base_url() ?>assets/frontend/img/three/ameexp.png"/>
                                       <div class="rect rect1">
                                          <p class="cont1">Rs.3666</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class="rect rect2">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class=" rect rect3">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p>
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect4">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect5">
                                       </div>
                                       <div class=" rect rect6"></div>
                                 </div>
                                 <div class="row3">
                                    <img class="axisbank"src="<?php echo base_url() ?>assets/frontend/img/three/axis.jpg"/>
                                       <div class="rect rect1">
                                          <p class="cont1">Rs.3666</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>

                                       </div>
                                       <div class="rect rect2">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class=" rect rect3">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="" style="color:black;font-size:10px;">Finance Charges</p>
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect4">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect5"></div>
                                       <div class=" rect rect6"></div>
                                 </div>
                                 <div class="row4">
                                    <img class="citibank" src="<?php echo base_url() ?>assets/frontend/img/three/citi.jpg"/>
                                       <div class="rect rect1">
                                          <p class="cont1">Rs.3666</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>

                                       </div>
                                       <div class="rect rect2">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class=" rect rect3">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p>
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect4">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect5">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect6">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                 </div>
                                 <div class="row5">
                                    <img class="hdfc" src="<?php echo base_url() ?>assets/frontend/img/three/hdfc.png"/>
                                       <div class="rect rect1">
                                          <p class="cont1">Rs.3666</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class="rect rect2">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class=" rect rect3">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p>
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect4">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                           
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p>
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect5">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect6">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                 </div>
                                 <div class="row6">
                                    <img class="hsbc" src="<?php echo base_url() ?>assets/frontend/img/three/hsbc.jpg"/>
                                       <div class="rect rect1">
                                          <p class="cont1">Rs.3666</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class="rect rect2">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class=" rect rect3">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p>
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect4">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p>
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect5">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect6"></div>
                                 </div>
                                 <div class="row7">
                                    <img class="icici" src="<?php echo base_url() ?>assets/frontend/img/three/icici.gif"/>
                                       <div class="rect rect1">
                                          <p class="cont1">Rs.3666</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class="rect rect2">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3">No Cost EMI</p>
                                       </div>
                                       <div class=" rect rect3">
                                          <p class="cont1">Rs.1833</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p>
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect4">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p>
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect5">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                       <div class=" rect rect6">
                                          <p class="cont1">Rs.977</p>
                                          <p class="cont2">(per month)</p>
                                          <p class="cont3" style="color:black;font-size:10px;">Finance Charges</p> 
                                          <p class="cont4">12%</p>
                                       </div>
                                 </div>
                              </div>
                                 
                           </div>
                       </div>
                       <div class="modal-footer">
                         <button type="button" class="btn btn-default closebtn" data-dismiss="modal">Close</button>
                       </div>
                     </div>
                     
                   </div>
                 </div>
                 
               </div>

         </div>
      </div>

      <div class="row">
         <div class="col-sm-6 moreone">
            <div class="more1">
               <input type="button" name="morebrand" value="More From Brand" class="morebtn1">
            </div>
            <div class="more2">
               <input type="button" name="similaritem" value="View Similar item " class="morebtn2">
            </div>
            <div  class="social-small">
               <ul>
                  <li class="social-circle">
                     <a href="#"><i class="fa fa-facebook"> </i></a>
                  </li>
                  <li class="social-circle">
                     <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                  </li>
                  <li class="social-circle">
                     <a href="#"><i class="fa fa-pinterest"> </i></a>
                  </li>
               </ul>
            </div>
         </div>
      </div>
      <div  class="row">
         <div class="col-sm-12">
            <div class=" col-sm-6 productDescription1 ">
               <h3 class="detailsproduct">Details</h3>
               <div class="col-sm-4">
                  <ul >
                     <li><strong>Brand</strong> </li>
                     <li><strong>Dimension</strong> </li>
                     <li><strong>Warranty</strong> </li>
                     <li><strong>Assembly</strong> </li>
                     <li><strong>Primary Material</strong> </li>
                     <li><strong>Height</strong> </li>
                     <li><strong>Width</strong> </li>
                     <li><strong>Depth</strong> </li>
                     <li><strong>Seating Height</strong> </li>
                     <li><strong>Sku</strong> </li>
                  </ul>
               </div>
               <div class="col-sm-1">
                  <ul>
                     <li><b>:</b></li>
                     <li><b>:</b></li>
                     <li><b>:</b></li>
                     <li><b>:</b></li>
                     <li><b>:</b></li>
                     <li><b>:</b></li>
                     <li><b>:</b></li>
                     <li><b>:</b></li>
                     <li><b>:</b></li>
                  </ul>
               </div>
               <div class="col-sm-7">
                  <ul>
                     <li>Tvs Scooter</li>
                     <li>2422*89898</li>
                     <li>12 Month Warranty</li>
                     <li>Carpentar Assembly</li>
                     <li>Enineer wood</li>
                     <li>35.00 inches</li>
                     <li>63.00 inches</li>
                     <li> 86.0 inches</li>
                     <li>12</li>
                     <li>FN1703868-P-WH5046</li>
                  </ul>
               </div>
            </div>
            <div class="col-sm-6 productDescription2">
               <h3 class="detailsproduct "> Overview</h3>
               <p class="paragraph1">Modern Furniture reflects the design philosophy of form following function prevalent in modernism. These designs represent the ideals of cutting excess, practicality and an absence of decoration.</p>
               <p class="paragraph1">The forms of furniture are visually light (like in the use of polished metal and engineered wood) and follow minimalist principles of design which are influenced by architectural concepts like the cantilever. Modern furniture fits best in open floor plans with clean lines that thrive in the absence of clutter.</p>
               <p class="paragraph1">Every 5 minutes, an item of Furniture sells on Pepperfry.com.</p>
               <p>Furniture bought on Pepperfry.com is shipped for free, So go ahead and buy with confidence.</p>
            </div>
         </div>
         <div class="col-sm-6">
         </div>
      </div>
      <div class="similarproduct1">
         <h3 class="similarhead">Similar Products</h3>
         <small class="yourchoice">Get Your Choice</small>
      </div>
      <div class="row contentproduct">
         <div class="col-sm-3 ">
            <div class="b b1">
               <div class="card ">
                  <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                  <div class="card-body">
                     <h4 class="card-title nameveh">Lohial</h4>
                     <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                     <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                     <div class="overlay">
                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                        <div class="text2"><a href="#">BUY NOW</a> </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-sm-3">
            <div class="b b1">
               <div class="card ">
                  <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                  <div class="card-body">
                     <h4 class="card-title nameveh">Lohial</h4>
                     <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                     <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                     <div class="overlay">
                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                        <div class="text2"><a href="#">BUY NOW</a> </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-sm-3">
            <div class="b b1">
               <div class="card ">
                  <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                  <div class="card-body">
                     <h4 class="card-title nameveh">Lohial</h4>
                     <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                     <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                     <div class="overlay">
                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                        <div class="text2"><a href="#">BUY NOW</a> </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-sm-3">
            <div class="b b1">
               <div class="card ">
                  <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                  <div class="card-body">
                     <h4 class="card-title nameveh">Lohial</h4>
                     <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                     <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                     <div class="overlay">
                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                        <div class="text2"><a href="#">BUY NOW</a> </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <script type="text/javascript">
      var $slide = $('.slide'),
         $slideGroup = $('.slide-group'),
         $bullet1 = $('.bullet1');
      
      var slidesTotal = ($slide.length - 1),
         current = 0,
         isAutoSliding = false;
      
      $bullet1.first().addClass('current');
      
      var clickSlide = function() {
        //stop auto sliding
      window.clearInterval(autoSlide);
      isAutoSliding = false;
      
      var slideIndex = $bullet1.index($(this));
      
        updateIndex(slideIndex);
      };
      
      var updateIndex = function(currentSlide) {
        if(isAutoSliding) {
          if(current === slidesTotal) {
            current = 0;
          } else {
            current++;
          }
        } else {
            current = currentSlide;
        }
      
        $bullet1.removeClass('current');
        $bullet1.eq(current).addClass('current');
      
        transition(current);
      };
      
      var transition = function(slidePosition) {
          $slideGroup.animate({
            'top': '-' + slidePosition + '00%'
          });
      };
      
      $bullet1.on( 'click', clickSlide);
      
      var autoSlide = window.setInterval(updateIndex, 2000);
      
      function myFunction() {
       		 document.getElementById("viewmore").style.display = "block";
      }		
      function myEasyFunction() {
             document.getElementById("easyhidedata").style.display = "block";
      }     
       function cancleFunction() {
       		 document.getElementById("viewmore").style.display = "none";
      }	
      function myEasyCancleFunction() {
             document.getElementById("easyhidedata").style.display = "block";
      }     	 
      function change(event) {
				var image=document.getElementById("sco");
				image.src=event.target.getAttribute("src");
				var p=document.getElementById("smlSco");
				p.addClass("current");
		}
      var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("bullet2");
  if (n > slides.length) {slideIndex = 1} 
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none"; 
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block"; 
  dots[slideIndex-1].className += " active";
}
   </script>
</body>