<style type="text/css">
.A123{
    font-size: 12px !important;
    height: 0px; 
     margin-top: -4px; 
    
}
.sunav{
    min-height: 0px !important;
    
}
.outerblock {
    position: relative;
    margin-left: 300px;
    top: 20px;
}

.tab-menu {
    width: 142px;
    height: 120px;
}

.tab-menu img {
    width: 60px;
    height: 60px;
}

.nav-tabs .tab-menu a {
    color: white;
    text-align-last: center;
}

.nav-tabs>li.active>a
{
    color: #57b952 !important;
    cursor: default;
    background-color: #fff;
    border: 0px solid #57b952;
    font-size: 12px;
        border-radius: 0px !important;
}
.nav-tabs>li.active>a:focus,
.nav-tabs>li.active>a:hover {
    color: #57b952 !important;
    cursor: default;
    background-color: #fff;
    border: 1px solid #57b952;
    font-size: 12px;
        border-radius: 0px !important;
}

.nav-tabs > li > a {
    margin-right: 2px;
    line-height: 1.42857143;
    border: 0px solid transparent;
    border-radius: 0px 0px 0 0;
    background: #fff;
    color: #3051a0 !important;
    border-radius: 0px;
}
.nav-tabs > li > a:hover {
    background-color: #fff !important;
    border: 0px solid #57b952 !important;
}
.nav-tabs > li {
    float: left;
    margin-bottom: -1px;
    padding: 15px 7px !important;
}
.nav-tabs {
    border-bottom: 1px solid #fff;
}

.content-area {
    width: 10px;
    height: 600px;
    color: #f5f5f5;
    border: 1px solid;
}

.outermenublock {
    position: relative;
    background-color: #f5f5f5;
    width: 100%;
    height: 900px;
}
.tab-content {
    border: 2px solid #eee;
    width: 73%;
    top: 54px !important;
    position: relative;
}
.submenu {
    width: 300px;
    height: 70px;
    background-color: blue;
    z-index: 1;
    position: relative;
}


/************************* sticky nav */
.truncate {
     width: auto;
    height: 52px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    margin-top: 2px;
    margin-left: 40px;
    left: 108px;
    

}
.menuwidht{
     width: 138px;
    height: 43px;
}
.mclr{
    margin-top:1px;
}
.affix {

    top:0;
    width: 100%;
    z-index: 9999 !important;
} 
#mainmenu{
    display: none;
    height: 90px;
    margin-left:-315px;
    background-color: #3e3b3b;
}
.filter1 {
    color: #fff;
    float: left;
    margin-left: 100px;
    margin-top: 13px;
}
.filter2{
    position: relative !important;
    top: -5px !important;
}
.filter3{
    position: relative !important;
    top: 8px !important;
}
.sortby1 {
    margin-left: 462px;
}
.sort1 {
    color: #fff;
    /* float: left; */
    left: -159px;
    /* left: 31;8px; */
    top: 13px;
    position: relative;
}
.justcolor{
   background-color: #3051a0;
    /* margin-top: -4px; */
    /* margin-left: 10px; */
    width: 100%;;
    padding: 2px 1px !important;
}
.justcolor a{
    color: #fff;
}
.justcolor li a:hover{
    /*background-color: white;*/
    color:black;
    width:100%;
    height:39px;
    margin-top: 0px;
    font-size: 12px;
    }
.main-nav{
height: 70px;
    position: relative;
    /* left: 0%; */
    /* margin-top: 10px; */
    /* margin: auto; */
    background-color: #fff;
}
.truncate a{
    color: grey;
}
.sub-nav{

}

.filter {
    color: #888;
    float: left;
    margin-left: 100px;
    margin-top: 17px;
    margin-right: 10px;
    font-size: 13px !important;
}



.filtermenu ul li {
    border: 1px solid #ccc;
    background-color: #fff;
    margin-top: 10px;
}
.filtermenu{
    margin:13px 0px;
}
.color{
    width: 100%;
    height: 62px;
  
}
.color>li>a {
    padding: 7px 14px;
       color: #444;
       font-size: 12px !important;

}
.color>li>a:hover {
    padding: 7px 14px;
       color: #444;
       font-size: 12px !important;

}

.sort {
    color: gray;
    /* float: left; */
    left: -168px;
    top: 20px;
    position: relative;
}

.sortby {
   
    margin-left: 470px;
}


/*. submenu ..*/

.brand-menu,
.price-menu,.dimension-menu, .primary-menu, .material-menu,.relevance-menu {
    display: none;
    position: absolute;
    font-size: 14px;
    font-weight: bold;
    border: 1px solid gray;
    box-shadow: 1px 1px 1px 2px gray;
    width: 100px;
    height: 100px;
    padding: 10px;
    z-index: 100;
    background-color: #fff;
    
}
.brand-menu1,
.price-menu1,.dimension-menu1, .primary-menu1, .material-menu1,.relevance-menu1 {
    display: none;
    position: absolute;
    font-size: 14px;
    font-weight: bold;
    border: 1px solid gray;
    box-shadow: 1px 1px 1px 2px gray;
    width: 120px;
    height: 120px;
    padding: 10px;
    z-index: 300;
    background-color: #fff;
}

.brand-menu:before,
.price-menu:before,.dimension-menu:before, .primary-menu:before, .material-menu:before,
.relevance-menu:before{
    content: "";
    position: absolute;
    width: 10px;
    height: 10px;
    margin-top: -16px;
    background-color: #fff;
    border-left: 1px solid gray;
    border-top: 1px solid gray;
    transform: rotate(45deg);
}
.brand-menu1:before,
.price-menu1:before,.dimension-menu1:before, .primary-menu1:before, .material-menu1:before,
.relevance-menu1:before{
    content: "";
    position: absolute;
    width: 10px;
    height: 10px;
    margin-top: -16px;
    background-color: #fff;
    border-left: 1px solid gray;
    border-top: 1px solid gray;
    transform: rotate(45deg);
}

.brand-menu a,
.price-menu a,.dimension-menu a, .primary-menu a, .material-menu a,.relevance-menu a {
    margin-left:0px;
    color: black;
}

.brand-menu a:hover,
.price-menu a:hover,.dimension-menu a:hover, .primary-menu a:hover, 
.material-menu a:hover,.relevance-menu a:hover {
    color: #25d40c;
}
.brand-menu1 a,
.price-menu1 a,.dimension-menu1 a, .primary-menu1 a, .material-menu1 a,.relevance-menu1 a {
     margin-left:0px;
    color: black;
}

.brand-menu1 a:hover,
.price-menu1 a:hover,.dimension-menu1 a:hover, .primary-menu1 a:hover, 
.material-menu1 a:hover,.relevance-menu1 a:hover {
    color: #25d40c;
}
.bran:hover .brand-menu{
display: block;
}
.pri:hover .price-menu{
display: block;
}
.dim:hover .dimension-menu{
display: block;
}
.mat:hover .material-menu{
display: block;
}
.prim:hover .primary-menu{
display: block;
}
.relevance:hover .relevance-menu{
display: block;
}
.bran1:hover .brand-menu1{
display: block;
}
.pri1:hover .price-menu1{
display: block;
}
.dim1:hover .dimension-menu1{
display: block;
}
.mat1:hover .material-menu1{
display: block;
}
.prim1:hover .primary-menu1{
display: block;
}
.relevance1:hover .relevance-menu1{
display: block;
}

a {
    text-decoration: none;
}
.b {
    border: 1px solid gray;
    box-shadow: 2px 2px 2px 1px gray;
}

.b1:hover {
    content: "kkkk";
    opacity: transparent;
    background-color: gray;
}

.card-body {
    color: black;
}
.nameveh{
        margin-left: 14px;
    margin-top: 10px;
}
.soldby{
        margin-left: 14px;
    margin-top: 10px;
    font-size: 15px;
}
.card-body h4 {
  
}
.card-price{
     margin-left: 14px;
    margin-top: 10px;
    margin-bottom: 10px;
}
.card-body .btn {
    margin-left: 70px;
    margin-bottom: 5px;
}

.breakspace {
    width: 100%;
    height: 20px;
}
.originalprice{
    position: relative;
    left:6%;
    color: gray;
}
.tab-content{
    width: 100%;
    margin: 0;
    padding: 0;

}
.overlay {
 position: absolute;
    bottom: 100%;
    left: 15px;
    right: 0;
    background-color: #50a94863;
    overflow: hidden;
    width: 90%;
    height: 0;
    transition: .5s ease;
}

.card:hover .overlay {
  bottom: 0;
  height: 100%;
}

.text1 {
   border: 2px solid #10106f;
    /* width: 100px; */
    width: 150px;
    height: 45px;
    /* height: 40px; */
    padding-top: 10px;
    color: white;
    font-weight: bold;
    font-size: 18px;
    padding-top: 9px;
    position: absolute;
    top: 95%;
    left: 28%;
    background-color: #07078a;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    text-align: center;
    color:white;
}
.text2 {
     border: 2px solid #10106f;
    /* width: 100px; */
    width: 110px;
    height: 45px;
    /* height: 40px; */
    padding-top: 10px;
    color: white;
    font-weight: bold;
    font-size: 18px;
    padding-top: 9px;
    position: absolute;
    top: 95%;
    left: 80%;
    background-color: #07078a;
    -webkit-transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
    text-align: center;
    color:white;
}
.text1 a, .text2 a{
    color: white;
}
.priceitem{
    position: relative;
    left: 26%;
}
.actualprice{
position: relative;
    font-weight: bold;
}
.mclr1{
    margin-top: 5px;
    margin-left: 0px;
    
}

  /* ****************Responsive tab css*********************************
  ****************************************** */

 @media only screen and (max-width: 1024px) {
   .outerblock{
    margin-left: 15%;
   }
   #mainmenu {
    
    margin-left: -169px;
    
}
.truncate{

    left: 23px;
    /* left: -21px; */
   
    width: 150px;
}
.filter1{
    margin-left: 20px;
    
}

.sort1 {
    left: -159px;
}
.sortby1 {
    margin-left: 227px;
}
.sort{
    left:-168px;
}
.sortby {
    
    margin-left: 156px;
}
.card-body .btn {
    margin-left: 40px;
    
}
}
@media only screen and (max-width: 768px) {
.outerblock{
    margin-left: 2%;
   }
#mainmenu {
    display: none;
    height: 90px;
    margin-left: -30px;
    background-color: #3e3b3b;
}
.truncate{
    width: 148px;
    margin-top: 2px;
    margin: 0;
    left: 0;
 
}
.filter1{
    margin-left: 10px;
    margin-right: 0;

}
.sort1{
display: none;
margin: 0;
padding: 0;
}
.sortby1{
margin-left: 0;
}
.filter{
    margin-left: 0;
    margin-right:0;
}
.sortby {
    margin-left: 15px;
}
.sort{
    display: none;
}
@media only screen and (max-width: 425px) {
    .outerblock{

    }
    #mainmenu {
    display: none !important;
}
.main-nav-tabs{

}
.main-nav-tabs  li{
   width: 62%;
    margin-bottom: 10px;
    margin-left: 20%;
    position: relative;
    /* margin: auto; */
}
.filtermenu {
    margin-bottom: 300px;
    /* margin: 20px; */
    text-align: center;
    margin-right: 100px;
    margin-left: 100px;
}
.filter, .sort{
    display: none !important;
}
.navbar{
    background-color: none;
}
}

.navbar-nav>li>a{
        line-height: 17px !important;
}


</style>
    <body>
        <div class="container-fluid outerblock">
            <div data-spy="affix" data-offset-top="200" id="mainmenu">
               <ul class="nav nav-tabs main-nav">
                <li class="active truncate"><a data-toggle="tab" href="#home" class="menuwidht"> <h5 class="mclr">Modern shoe..</h5></a></li>
                <li class="truncate"> <a data-toggle="tab" href="#menu1" class="menuwidht"><h5 class="mclr">Modern shoe...</h5></a></li>
                <li class="truncate"><a data-toggle="tab" href="#menu2" class="menuwidht" ><h5 class="mclr"> Modern Engineer..</h5></a></li>
                <li class="truncate"><a data-toggle="tab" href="#menu3" class="menuwidht"><h5 class="mclr"> Modern shoe..</h5></a></li>
                <li class="truncate"><a data-toggle="tab" href="#menu4" class="menuwidht"><h5 class="mclr"> Modern shoe..</h5></a></li>
                </ul>
              <nav class="navbar sub-nav sunav" >
                <ul class="nav navbar-nav justcolor ">
                    <b class="filter1 filter2">Filter By:</b>
                    <li class="active bran1"><a href="#" class=" brand1 A123">Brand &#9660;</a>
                        <ul class="brand-menu1">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="pri1"><a href="#" class="price1 A123">Price  &#9660;</a>
                        <ul class="price-menu1">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>
                            
                        </ul>
                    </li>
                    <li class="dim1"><a href="#" class="dimension1 A123">Dimension  &#9660;</a>
                        <ul class="dimension-menu1">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="mat1"><a href="#" class="material1 A123">material  &#9660;</a>
                      <ul class="material-menu1">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="prim1"><a href="#" class="primary1 A123">Primary material  &#9660;</a>
                        <ul class="primary-menu1">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <b class="sort1 filter3" >Sort By:</b>
                    <li class="sortby1 relevance1" ><a href="#" class="A123" >Relevance  &#9660;</a>
                        <ul class="relevance-menu1">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                </ul>

              </nav>
          </div>
          <ul class="nav nav-tabs main-nav-tabs">
                <li class="active tab-menu"><a data-toggle="tab" href="#home" class="one1"><img src="<?php echo base_url() ?>assets/frontend/img/one/3.png"> <h5 class="mclr1">Modern shoe <br>racks</h5></a></li>
                <li class="tab-menu"> <a data-toggle="tab" href="#menu1"><img src="<?php echo base_url() ?>assets/frontend/img/one/3.png"> <h5 class="mclr1">Modern shoe<br> racks</h5></a></li>
                <li class="tab-menu"><a data-toggle="tab" href="#menu2"><img src="<?php echo base_url() ?>assets/frontend/img/one/3.png"><h5 class="mclr1"> Modern Engineer <br>shoewood</h5></a></li>
                <li class="tab-menu"><a data-toggle="tab" href="#menu3"><img src="<?php echo base_url() ?>assets/frontend/img/one/3.png"><h5 class="mclr1"> Modern shoe<br> racks</h5></a></li>
                <li class="tab-menu"><a data-toggle="tab" href="#menu4"><img src="<?php echo base_url() ?>assets/frontend/img/one/3.png"><h5 class="mclr1"> Modern shoe<br> racks</h5></a></li>
          </ul>
    </div>
    <div class=" tab-content">
        <div id="home" class="tab-pane fade in active outermenublock">

            <nav class="navbar filtermenu" >

                <ul class="nav navbar-nav color">
                    <b class="filter">Filter By:</b>
                    <li class="active bran"><a href="#" class="brand ">Brand &#9660;</a>
                        <ul class="brand-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="pri"><a href="#" class="price" >Price  &#9660;</a>
                        <ul class="price-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="dim"><a href="#" class="dimension">Dimension  &#9660;</a>
                        <ul class="dimension-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="mat"><a href="#" class="material">material  &#9660;</a>
                      <ul class="material-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="prim"><a href="#" class="primary">Primary material  &#9660;</a>
                        <ul class="primary-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <b class="sort" >Sort By:</b>
                    <li class="sortby relevance" ><a href="#" >Relevance  &#9660;</a>
                        <ul class="relevance-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                </ul>

            </nav>
           
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                      <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                          <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="breakspace"></div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class=" b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div id="menu1" class="tab-pane fade outermenublock">
            <nav class="navbar filtermenu" >

                <ul class="nav navbar-nav color">
                    <b class="filter">Filter By:</b>
                    <li class="active bran"><a href="#" class="brand">Brand &#9660;</a>
                        <ul class="brand-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="pri"><a href="#" class="price">Price  &#9660;</a>
                        <ul class="price-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="dim"><a href="#" class="dimension">Dimension  &#9660;</a>
                        <ul class="dimension-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="mat"><a href="#" class="material">material  &#9660;</a>
                      <ul class="material-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="prim"><a href="#" class="primary">Primary material  &#9660;</a>
                        <ul class="primary-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <b class="sort" >Sort By:</b>
                    <li class="sortby relevance" ><a href="#" >Relevance  &#9660;</a>
                        <ul class="relevance-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                </ul>

            </nav>
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                      <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                          <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="breakspace"></div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class=" b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div id="menu2" class="tab-pane fade outermenublock">
            <nav class="navbar filtermenu" >

                <ul class="nav navbar-nav color">
                    <b class="filter">Filter By:</b>
                    <li class="active bran"><a href="#" class="brand">Brand &#9660;</a>
                        <ul class="brand-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="pri"><a href="#" class="price">Price  &#9660;</a>
                        <ul class="price-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="dim"><a href="#" class="dimension">Dimension  &#9660;</a>
                        <ul class="dimension-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="mat"><a href="#" class="material">material  &#9660;</a>
                      <ul class="material-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="prim"><a href="#" class="primary">Primary material  &#9660;</a>
                        <ul class="primary-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <b class="sort" >Sort By:</b>
                    <li class="sortby relevance" ><a href="#" >Relevance  &#9660;</a>
                        <ul class="relevance-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                </ul>

            </nav>
           <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                      <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                          <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="breakspace"></div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class=" b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div id="menu3" class="tab-pane fade outermenublock">
            <nav class="navbar filtermenu" >

                <ul class="nav navbar-nav color">
                    <b class="filter">Filter By:</b>
                    <li class="active bran"><a href="#" class="brand">Brand &#9660;</a>
                        <ul class="brand-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="pri"><a href="#" class="price">Price  &#9660;</a>
                        <ul class="price-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="dim"><a href="#" class="dimension">Dimension  &#9660;</a>
                        <ul class="dimension-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="mat"><a href="#" class="material">material  &#9660;</a>
                      <ul class="material-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="prim"><a href="#" class="primary">Primary material  &#9660;</a>
                        <ul class="primary-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <b class="sort" >Sort By:</b>
                    <li class="sortby relevance" ><a href="#" >Relevance  &#9660;</a>
                        <ul class="relevance-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                </ul>

            </nav>
           <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                      <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                          <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="breakspace"></div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class=" b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div id="menu4" class="tab-pane fade outermenublock">
            <nav class="navbar filtermenu" >

                <ul class="nav navbar-nav color">
                    <b class="filter">Filter By:</b>
                    <li class="active bran"><a href="#" class="brand">Brand &#9660;</a>
                        <ul class="brand-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="pri"><a href="#" class="price">Price  &#9660;</a>
                        <ul class="price-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="dim"><a href="#" class="dimension">Dimension  &#9660;</a>
                        <ul class="dimension-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="mat"><a href="#" class="material">material  &#9660;</a>
                      <ul class="material-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <li class="prim"><a href="#" class="primary">Primary material  &#9660;</a>
                        <ul class="primary-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                    <b class="sort" >Sort By:</b>
                    <li class="sortby relevance" ><a href="#" >Relevance  &#9660;</a>
                        <ul class="relevance-menu">

                            <a href="#">copper</a><br>
                            <a href="#">copper</a> <br>
                            <a href="#">copper</a> <br>

                        </ul>
                    </li>
                </ul>

            </nav>
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                      <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                          <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="breakspace"></div>
                <div class="row">
                    <div class="col-sm-3">
                        <div class=" b b1">
                            <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="b b1">
                           <div class="card ">
                                <img class="card-img-top" src="<?php echo base_url() ?>assets/frontend/img/one/w5.png" alt="Card image">
                                <div class="card-body">
                                    <h4 class="card-title nameveh">Lohial</h4>
                                    <p class="soldby">Sold by &nbsp;<b>evmax</b></p>
                                    <p class="card-text card-price"><span class="actualprice"> &#x20b9; 100000.00</span><strike class="originalprice"> &#x20b9;120000.00</strike></p>
                                   
                                    <div class="overlay">
                                        <div class="text1"><a href="#">ADD TO CART</a> </div>
                                          <div class="text2"><a href="#">BUY NOW</a> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script type="text/javascript">
        
        
         // Identify target

        window.addEventListener('scroll', function(event) { // To listen for event
            event.preventDefault();

            if (window.scrollY <= 150) {
             // Just an example
             document.getElementById("mainmenu").style.backgroundColor = "#f5f5f5";
             document.getElementById("mainmenu").style.display = "none";
                
                                  // or default color
            } else {
              document.getElementById("mainmenu").style.backgroundColor = "black";
            document.getElementById("mainmenu").style.display = "block";
                
                 
            }

        });
        



        $(document).ready(function() {
            

        });
    </script>


</body>