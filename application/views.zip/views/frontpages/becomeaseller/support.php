	<div class="w3-content w3-display-container">
			<a href="<?php echo base_url() ?>BecomeASeller/about#enquirynow"><img src="<?php echo base_url() ?>assets/frontend/img/search.png" class="bannersearchicn d-none d-xl-block"></a> 
  			<img class="mySlides" src="<?php echo base_url() ?>assets/layout2/images/enquiry/support-partners.png" usemap="#workmap" style="width:100%">
                        
  			<p class="partnrstxt">Join Our Network Today</p>
  		</div>

  		<map name="workmap">
  			<area shape="rect" coords="20,200,170,0" alt="logo" href="<?php echo base_url() ?>">
  			
		</map>

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap12">

				<div class="container clearfix">

					<div id="section-pricing" class="heading-block title-center page-section">
						<h2 class="colr2">Expert Support Partners</h2>
						<span>Expert support from our “Expert Support Partners”</span>
					</div>

					<div>
						<p class="lead divcenter bottommargin supportpartnr">Our network of qualified third-party Expert Support Partners will help you with everything you need starting from shooting great images for your products to delivering them to destination. our Expert Support Partners help you with every step of selling online.</p>
					</div>

					<div class="row clearfix">

						<div class="col-lg-6">

							<h3 class="colr1">Our Expert Support Partners can help you with</h3>

							<ul class="iconlist iconlist-color nobottommargin myenqc2">
									<li><i class="icon-ok"></i> Imaging and Cataloging for your products. </li>
									<li><i class="icon-ok"></i> Manage advertising your products on Prime Product Program </li>
									<li><i class="icon-ok"></i> Packing your products. </li>
									<li><i class="icon-ok"></i> Transporting your products to destination. </li>
									
							</ul>

						</div>

						<div class="col-lg-6">

							<h3 class="colr1">How it works</h3>

							<ul class="iconlist iconlist-color nobottommargin myenqc2">
									<li><i class="icon-ok"></i> Choose Expert Support Partner from “Expert Support Partner” list on Merchant websys. </li>
									<li><i class="icon-ok"></i> Talk to them on your requirement </li>
									<li><i class="icon-ok"></i> Provide required details </li>
									<li><i class="icon-ok"></i> Get your service done </li>
									<li><i class="icon-ok"></i> Pay only when your job is done. </li>
							</ul>

						</div>

					</div>

				</div>

				
			</div>

			

		</section><!-- #content end -->