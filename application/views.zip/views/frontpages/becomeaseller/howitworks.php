		<div class="w3-content w3-display-container"> 
			<a href="<?php echo base_url() ?>BecomeASeller/about#enquirynow"><img src="<?php echo base_url() ?>assets/frontend/img/search.png" class="bannersearchicn d-none d-xl-block"></a>
  			<img class="mySlides" src="<?php echo base_url() ?>assets/layout2/images/enquiry/howitworks.png" usemap="#workmap" style="width:100%">
                        
  		</div>

  		<map name="workmap">
  			<area shape="rect" coords="40,190,100,310" alt="logo" href="<?php echo base_url() ?>">
  			<area shape="rect" coords="150,180,300,250" alt="buttn" href="<?php echo base_url() ?>BecomeASeller/about#enquirynow">
  			
		</map>



		<!-- Content
		============================================= -->
	<section id="content">

			<div class="content-wrap">
				<div class="container clearfix">
					<div class="heading-block center">
							<h3> <span>How It Works </span></h3>
						</div>
					<div class="col_two_fifth howitwrks">
						<img src="<?php echo base_url() ?>assets/layout2/images/enquiry/processs.png" alt="" class="stepheight" usemap="#workmap1">
					</div>
					<map name="workmap1">
  			               <area class="mapStep" shape="rect" coords="70,75,100,110" alt="logo" id="tabs-21">
  			               <area class="mapStep" shape="rect" coords="240,75,270,110" alt="buttn" id="tabs-22">
  			  <area shape="rect" class="mapStep" coords="330,140,370,170" alt="buttn" id="tabs-23">
  			   <area shape="rect"class="mapStep"  coords="270,210,320,250" alt="buttn" id="tabs-24">
  			  <area shape="rect" class="mapStep" coords="160,210,200,250" alt="buttn" id="tabs-25">
  			  <area shape="rect" class="mapStep" coords="75,250,120,290" alt="buttn" id="tabs-26">
  			  
		         <area shape="rect" class="mapStep" coords="130,340,170,380" alt="buttn" id="tabs-27">
  			  
		        <area shape="rect" class="mapStep" coords="310,340,350,380" alt="buttn" id="tabs-28">
		       
		                 </map>
					<div class="col_three_fifth col_last howitwrks">
						<div class="tabs side-tabs nobottommargin clearfix" id="tab-6">

							<ul class="tab-nav tab-nav2 clearfix myenqc5">
								<li class="stepOption" id="litabs-21"><a href="#tabs-21"><i class="icon-home2"></i>Step 1</a></li>
								<li  class="stepOption" id="litabs-22"><a href="#tabs-22">Step 2</a></li>
								<li  class="stepOption" id="litabs-23"><a href="#tabs-23">Step 3</a></li>
								<li   class="stepOption"id="litabs-24"><a href="#tabs-24">Step 4</a></li>
								<li   class="stepOption" id="litabs-25"> <a href="#tabs-25">Step 5</a></li>
								<li  class="stepOption" id="litabs-26"><a href="#tabs-26">Step 6</a></li>
								<li  class="stepOption" id="litabs-27"><a href="#tabs-27">Step 7</a></li>
								<li   class="stepOption" id="litabs-28"><a href="#tabs-28">Step 8</a></li>
							</ul>

							<div class="tab-container">

								<div class="tab-content clearfix divtabs-21 section center nobg" id="tabs-21">
									<h5 class="myenqc4 h1 t700 pulse animated" data-animate="pulse">Send Enquiry form </h5>
								</div>
								<div class="tab-content clearfix divtabs-22" id="tabs-22">
									<h5 class="myenqc6 h1 t700 pulse animated" data-animate="pulse"><span class="myenqc10">Receive Registration Form Link</span> </h5>
									<p class="maxpara">This link explains step by step process to get registered on evmax platform. All you need to do is provide your business details,bank account details and your tax information.</p> 
								</div>
								<div class="tab-content clearfix divtabs-23" id="tabs-23">
									<h5 class="myenqc44 h1 t700 pulse animated" data-animate="pulse">Submit registration form</h5>
								</div>
								<div class="tab-content clearfix divtabs-24"  id="tabs-24">
									<h5 class="myenqc8 h1 t700 pulse animated" data-animate="pulse"><span class="myenqc10">Your evmax dashboard </span></h5> 
									<p class="maxpara">We setup your business and send you welcome message with user id  andPassword to access your “evmax merchant websys” dashboard.Keep track of your account performance through your personalized performance dashboard and customized reports.
									</p>
								</div>

								<div class="tab-content clearfix divtabs-25" id="tabs-25">
									<h5 class="myenqc6 h1 t700 pulse animated" data-animate="pulse"><span class="myenqc10">List your products</span> </h5>
									<p class="maxpara">easy-to-use product listing tools helps you to list your products and services on evmax online store. Our team can help you create a best product catalogue for minimal charges.</p>
								</div>
								<div class="tab-content clearfix divtabs-26" id="tabs-26">
									<h5 class="myenqc9 h1 t700 pulse animated" data-animate="pulse"><span class="myenqc10">Start selling </span></h5>
									<p class="maxpara">Start selling on evmax online store in minutes. evmax customers can view your products as soon as your product is approved, and you start receiving orders. As soon as you receive an order you can view and manage it using an easy to use order management dashboard.
									</p>
								</div>

								<div class="tab-content clearfix divtabs-27" id="tabs-27">
									<h5 class="myenqc7 h1 t700 pulse animated" data-animate="pulse"><span class="myenqc10">Packing Shipping and delivery</span> </h5>
									<p class="maxpara"> Pack the products and notify “Ready for pickup” on your dashboard. evmax partner picks products from you and deliver to delivery address. You can also upgrade to evmax fulfilment </p>
									<p class="maxpara">you can store inventory in our evmax studios and we will pick and ship products to customers directly.
									</p>
								</div>
								<div class="tab-content clearfix divtabs-28" id="tabs-28">
									<h5 class="myenqc6 h1 t700 pulse animated" data-animate="pulse"><span class="myenqc10">Timely Payments </span> </h5>
									<p class="maxpara"> Payment is credited directly into your account after deducting our fees and commission.We deduct fees only after you make successful sale.</p>
								</div>

								
							</div>

						</div>
					</div>
						
				</div>

			</div>

		</section><!-- #content end -->
                <script type="text/javascript">
	
	 $(document).ready(function(){
	 
			 var mapId=0;
			 
			 $(".mapStep").click(function(){
			 
				 mapId=$(this).attr("id");
					   
					   
					   //steps class
					   
					  $(".ui-tabs-tab").removeClass("ui-state-hover ui-tabs-active ui-state-active");
					  $("#li"+mapId+"").addClass("ui-state-hover ui-tabs-active ui-state-active");

					  
					  //display div class
					  
					  
						$(".tab-content").hide();
					   
						 $(".div"+mapId+"").show().attr("aria-hidden","false");
              });
		 
 
			 $(".stepOption").click(function(){
					 
					 var presentId=$(this).attr("id");
					 var oldId="li"+mapId;
					 
					 if(presentId!=oldId)
					 {
						if(mapId!=0)
							{
								$("#li"+mapId+"").removeClass("ui-state-hover ui-tabs-active ui-state-active");

							   $(".div"+mapId+"").hide().attr("aria-hidden","true");
							}
					 }
		});
 });
 </script>