<div class="w3-content w3-display-container">
 			<a href="<?php echo base_url() ?>BecomeASeller/about#enquirynow"><img src="<?php echo base_url() ?>assets/frontend/img/search.png" class="bannersearchicn d-none d-xl-block"></a>
  			<img class="mySlides" src="<?php echo base_url() ?>assets/layout2/images/enquiry/Advertise.png" usemap="#workmap" style="width:100%">
                        
  		</div>

  		<map name="workmap">
  			<area shape="rect" coords="180,0,500,350" alt="logo" href="<?php echo base_url() ?>">
  			
		</map>

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div id="section-pricing" class="heading-block title-center nobottomborder page-section">
						<h2 class="colr2">Advertise on evmax</h2>
					</div>

					<div class="accordion accordion-bg clearfix">

							<div class="acctitle"><span class="myenqc3"></span></div>

							<div class="acc_content clearfix">
								<h4 class="colr1">Prime Product Advantage</h4>
								<ul class="iconlist iconlist-color nobottommargin myenqc2">
									<li><i class="icon-ok"></i> As a merchant you can use Prime Products Program to make your products stand out from other competitor products. </li>
									<li><i class="icon-ok"></i> Your product will be displayed top on search results</li>
									<li><i class="icon-ok"></i> High visible to relevant and targeted customers to increase your sales.</li>
									<li><i class="icon-ok"></i> You get a change to display your own attractive display ad banner.</li>
									<li><i class="icon-ok"></i> Less display fees and you only pay when your ad is clicked.</li>
									<li><i class="icon-ok"></i> Advertise to customers across evmax web and mobile app.</li>
									
								</ul>
							</div>

							

							

						</div>


						<a href="<?php echo base_url() ?>BecomeASeller/about#enquirynow"><button type="button" class="btn btn-primary btn-lg btn-block butnpric1">Become Merchant Today </button>
						</a>

				</div>

				
			</div>

			

		</section><!-- #content end -->