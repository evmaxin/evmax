<style>
    .f-nav{
        display: none !important;
    }
</style>
<div id="msg1" class="row visible-lg visible-md hidden-xs hidden-sm" style="margin: 0 auto !important;position:  relative;left: 30%;top:  11px;">
           <?php if(isset($_REQUEST['q'])&&($_REQUEST['q']==="success")){ ?> 
              <div class="alert alert-success alert-dismissable col-md-4"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <?php  echo $_REQUEST['msg'];?>
          </div>
          <?php } ?>
      </div>
<div id="msg2" class="row visible-xs visible-sm hidden-lg hidden-md">
             <?php if(isset($_REQUEST['q'])&&($_REQUEST['q']==="success")){ ?>
              <div class="alert alert-success alert-dismissable col-md-4"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <?php  echo $_REQUEST['msg'];?>
          </div>
          <?php } ?>
      </div>
<div class="w3-content w3-display-container">
				<a href="<?php echo base_url() ?>BecomeASeller/about#enquirynow"><img src="<?php echo base_url() ?>assets/frontend/img/search.png" class="bannersearchicn d-none d-xl-block"></a> 
       			<img class="mySlides" src="<?php echo base_url() ?>assets/layout2/images/enquiry/aboutevecosys.png" usemap="#workmap" style="width:100%">
                        
  		</div>

  		
		<map name="workmap">
  			<area shape="rect" coords="180,0,500,350" alt="logo" href="<?php echo base_url() ?>" style="border:1px solid red;background-color: red;">
  			<area shape="rect" coords="700,180,200,250" href="#enquirynow">
                       
  			
		</map>


		<!-- Content
		============================================= -->
		<section id="content" style="margin-top: -21px;">

			<div class="content-wrap1">

				<div class="container clearfix">

					<div class="divcenter center clearfix" style="max-width: 900px;">
						<img class="bottommargin" src="images/logo-side.png" alt="">
                                                <h1>About  <span><a href="mailto:info@evmax.in?subject=Enquiry">evmax</a></span></h1>
						<h2 class="myenqc1">evmax is an electric vehicle E-Commerce online store focusing on design and development of sustainable integrated technology solutions for creating a viable ecosystem for the faster adoption of electric vehicles to encourage No Pollution Mobility.</h2>
						
					</div>
					
				</div>

			</div>

		</section><!-- #content end -->

		<section id="content">

			<div class="content-wrap1">

				<div class="container clearfix">
					

					<div class="row">
						<div class="col_one_fourth nobottommargin center abtecoimgs1">
							<div>
							<a href="<?php echo base_url() ?>BecomeASeller/advantages"><img src="<?php echo base_url() ?>assets/layout2/images/enquiry/Online-Sales.png" class="abtecoimgs" >
							</div>
							<p>Online Sales Channel</a></p>
						</div>

						<div class="col_one_fourth nobottommargin center abtecoimgs1">
							<div>
							<a href="<?php echo base_url() ?>BecomeASeller/advantages"><img src="<?php echo base_url() ?>assets/layout2/images/enquiry/nosubfee.png" class="abtecoimgs">
							</div>
							<p>No Subscription Fees</a></p>
						</div>

						<div class="col_one_fourth nobottommargin center abtecoimgs1">
							<div>
							<a href="<?php echo base_url() ?>BecomeASeller/advantages"><img src="<?php echo base_url() ?>assets/layout2/images/enquiry/delivery-icon.png" class="abtecoimgs">
							</div>
							<p>Strong Delivery Channel</a></p>
						</div>
					 
					 	<div class="col_one_fourth nobottommargin center col_last abtecoimgs1">
							<div>
							<a href="<?php echo base_url() ?>BecomeASeller/advantages"><img src="<?php echo base_url() ?>assets/layout2/images/enquiry/paymenttransfer.png" class="abtecoimgs">
							</div>
							<p>Instant Payment Transfer</a></p>
						</div>
						<div class="col_one_fourth nobottommargin center col_last abtecoimgs1">
							<div>
							<a href="<?php echo base_url() ?>BecomeASeller/advantages"><img src="<?php echo base_url() ?>assets/layout2/images/enquiry/dashboard-icon.png" class="abtecoimgs" >
							</div>
							<p>Merchant Dashboard</a></p>
						</div>
						<div class="col_one_fourth nobottommargin center col_last abtecoimgs1">
							<div>
							<a href="<?php echo base_url() ?>BecomeASeller/advantages"><img src="<?php echo base_url() ?>assets/layout2/images/enquiry/advertising.png" class="abtecoimgs" >
							</div>
							<p>Advertising Support</a></p>
						</div>
					 </div>


			</div>
		</section>
	<div class="section1 nobottommargin">
		<div class="container clearfix">
			<div class="heading-block center">
							<h3> <span>Commitments</span></h3>
						</div>
					<div class="row clearfix">
						<!-- Feature - 1
						============================================= -->
						<div class="col-md-4">
							<div class="feature-box media-box bottommargin">
								
								<div class="fbox-desc">
									<h3>True Partnerships</h3>
									<p>We bring together the right organizations to create true partnerships.</p>
								</div>
							</div>
						</div>

						<!-- Feature - 2
						============================================= -->
						<div class="col-md-4">
							<div class="feature-box media-box bottommargin">
								
								<div class="fbox-desc">
									<h3>Innovative Technology Platform</h3>
									<p>We make technology innovations quickly where we see the opportunity to add new solution partner for strengthening evmax platform.</p>
								</div>
							</div>
						</div>

						<!-- Feature - 3
						============================================= -->
						<div class="col-md-4">
							<div class="feature-box media-box bottommargin">
								
								<div class="fbox-desc">
									<h3>Strengthen Network</h3>
									<p>We strengthen our network to care for ourselves and partners.</p>
								</div>
							</div>
						</div>

						<!-- Feature - 4
						============================================= -->
						<div class="col-md-4">
							<div class="feature-box media-box bottommargin">
								
								<div class="fbox-desc">
									<h3>Connecting Customers</h3>
									<p>With our strong network we connect all our partners with customers.</p>
								</div>
							</div>
						</div>

						<!-- Feature - 5
						============================================= -->
						<div class="col-md-4">
							<div class="feature-box media-box bottommargin">
								
								<div class="fbox-desc">
									<h3>Pure No Pollution Moment</h3>
									<p>We are committed to sell only “No Pollution Vehicles” for no pollution future.</p>
								</div>
							</div>
						</div>

						<!-- Feature - 6
						============================================= -->
						<div class="col-md-4">
							<div class="feature-box media-box bottommargin">
								
								<div class="fbox-desc">
									<h3>By your side</h3>
									<p>We encourage and support you whatever business you do for strengthening evmax and partners business</p>
								</div>
							</div>
						</div>
					</div>

					
		</div><!-- Container End -->
	</div>

<section id="content">

	<div class="content-wrap1 content-wrap12">
		<div class="container clearfix">
			<div class="col_two_third resabt">
				<img src="<?php echo base_url() ?>assets/layout2/images/enquiry/business-modal.png">
			</div>

			<div class="col_one_third col_last">
				<h2 class="colr2 colr21 ">evmax integrated business model </h2>
				<span class="resabt2">We look to give customers a unique experience by blending together the best of online as well as offline platform.</span>
			</div>
	
		</div>
	</div>
</section>

<section id="content">

	<div class="content-wrap1">
		<div class="container clearfix">
			<h1 class="divcenter center">  <span class="ss2">Together for pure future movement</span></h1>
			<div id="portfolio" class="portfolio grid-container portfolio-3 clearfix">

					

						<article class="portfolio-item pf-media pf-icons">
							<div class="portfolio-image">
								<a href="#">
									<img src="<?php echo base_url() ?>assets/layout2/images/enquiry/Ravi.png" alt="">
								</a>
								
							</div>
							
						</article>

						<article class="portfolio-item pf-media pf-icons">
							<div class="portfolio-image">
								<a href="#">
									<img src="<?php echo base_url() ?>assets/layout2/images/enquiry/Vasu.png" alt="">
								</a>
								
							</div>
							
						</article>


					</div><!-- #portfolio end -->
			
		</div>
	</div>
</section>

<section id="enquirynow">

			<div class="content-wrap001">

				<div class="section1 row nopadding dark topmargin-sm">
					<div class="col-lg-5">
						<h2 class="headngenq">Evmax Merchant Enquiry Form </h2>
						<img src="<?php echo base_url() ?>assets/layout2/images/enquiry/Process.png">
					</div>
					<div id="booking-appointment-form1" class="col-lg-7 nopadding">
						<div class="bgcolor contact-widget1 col-padding" data-loader="button">
							<h2 class="frmheadg1">Evmax Enquiry Form </h2>
                                                        <span class="user"></span>
							<div class="contact-form-result"></div>
								<h4 class="frmheadg">Personal Information :</h4>
							<?php $this->load->view('frontpages/becomeaseller/enquiryform'); ?>

						</div>
					</div>
				</div>


			</div>

		</section><!-- #content end -->
                
                <script>
                $("#submit").on("click",function(e){
       
  //check for duplicate email

    if (($("input[name*='categories']:checked").length)<=0) {
        alert("You must check at least 1 category");
    return false
    }
    return true;
    
       
  
    }); 
    if ($(window).width() < 514) {
    $('#msg1').addClass('f-nav');
} else {
    $('#msg2').addClass('f-nav');
}
  function search_func(value,type) {
      
      if (value.length >= 3 ) {
          $.ajax({
                 type: "POST",
                data: {
                    value: value,
                    type: type
                },
                url: "<?php echo base_url(); ?>index.php/Ajax/checkForDuplicate",
                success: function(data)
                {
                    if(data === 'EMAIL_EXISTS')
                    {
                     $('.user')
                            .css('color', 'red')
                            .html("This email already exists!");
                    $('#submit').prop('disabled', true);
                    return false;
                     }
                     else if(data === 'MOBILE_EXISTS')
                    {
                       // alert();
                     $('.user')
                            .css('color', 'red')
                            .html("This mobile already exists!");
                    $('#submit').prop('disabled', true);
                    return false;
                     }
                    else
                    {
                      $('#submit').prop('disabled', false);
                      $('.user').css('color', '#f5f5f5').html("");
                    }
                   // if(data === 'EMAIL_NOT_EXISTS')
                }
            }); 
            }
  }
                </script>