
		<div class="w3-content w3-display-container"> 
			<a href="<?php echo base_url() ?>BecomeASeller/about#enquirynow"><img src="<?php echo base_url() ?>assets/frontend/img/search.png" class="bannersearchicn d-none d-xl-block"></a>
  			<img class="mySlides" src="<?php echo base_url() ?>assets/layout2/images/enquiry/pricing.png" usemap="#workmap" style="width:100%">
                        
  		</div>

  		<map name="workmap">
  			<area shape="rect" coords="20,200,170,0" alt="logo" href="<?php echo base_url() ?>">
  			
		</map>

		

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">
				<div class="container clearfix">
					<div class="heading-block center">
							<h3> <span>How We Charge You </span></h3>
					</div>
					<div class="row">
						<div class="col_one_third myenqc13 nobottommargin">

							<div class="feature-box fbox-center fbox-light fbox-effect nobottomborder">
							<div class="fbox-icon">
								<a href="#"><i class="i-alt noborder icon-cart"></i></a>
							</div>
							<h3>Listing Fees</h3><p class="subtitle">evmax charges listing fees starting from 2% or Rs.25/- whichever is applicable for listing your product on evmax technology platform. Listing fees varies by category</p>
							</div>

						</div>

						<div class="col_one_third myenqc13 nobottommargin">

							<div class="feature-box fbox-center fbox-light fbox-effect nobottomborder">
							<div class="fbox-icon">
								<a href="#"><i class="i-alt noborder icon-tags"></i></a>
							</div>
							<h3>Sales Fees</h3><p class="subtitle">evmax takes sales commission starting from 5%. Sales commission varies by category.</p>
							</div>

						</div>

						<div class="col_one_third nobottommargin col_last">
						 	<div class="feature-box fbox-center fbox-light fbox-effect nobottomborder">
							<div class="fbox-icon">
								<a href="#"><i class="i-alt noborder icon-truck"></i></a>
							</div>
							<h3>Delivery Fees</h3><p class="subtitle ">Shipping fees is charged based on volume and distance per item shipped.</p>
							</div>

						</div>
					</div>

					

						<a href="<?php echo base_url() ?>BecomeASeller/about#enquirynow"><button type="button" class="btn btn-primary btn-lg btn-block butnpric1">Sell on evmax now</button></a>
						


				</div>


			</div>

			
					
				

		</section><!-- #content end -->
