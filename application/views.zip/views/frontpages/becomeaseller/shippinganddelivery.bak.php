<div class="w3-content w3-display-container"> 
  			<img class="mySlides" src="<?php echo base_url() ?>assets/layout2/images/enquiry/shippingndelivary.png" usemap="#workmap" style="width:100%">
                        <a href="<?php echo base_url() ?>BecomeASeller/about#enquirynow"><img src="<?php echo base_url() ?>assets/frontend/img/search.png" class="bannersearchicn d-none d-xl-block"></a>
  		</div>

  		<map name="workmap">
  			<area shape="rect" coords="20,200,170,0" alt="logo" href="<?php echo base_url() ?>">
  			
		</map>

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="heading-block center">
							<h3> <span>Shipping and Delivery </span></h3>
						</div>

					<div class="col_two_fifth nobottommargin">
							<img src="<?php echo base_url() ?>assets/layout2/images/enquiry/shipping.png" alt="Image" class="shippngimg">
					</div>

					<div class="col_three_fifth nobottommargin col_last shippngpts">

						<p>Merchant websys account is powered with “Shipping and Delivery Management” which can handle an end to end delivery process. All you need to do is keep your product packed and ready and let us manage the logistics and customer service.</p>

						<div class="col_half nobottommargin">
							<ul class="iconlist iconlist-color nobottommargin">
								<li><i class="icon-caret-right"></i> Pick up from your doorstep</li>
								<li><i class="icon-caret-right"></i> Handle shipments</li>
								<li><i class="icon-caret-right"></i> Respond to buyers</li>
								<li><i class="icon-caret-right"></i> Keep you updated on every step of delivery</li>
							</ul>
						</div>

					</div>

				</div>

				
			</div>

			<div class="promo promo-light promo-full  text-left bottommargin-lg header-stick notopborder">
					<div class="container clearfix">
						<div class="col_two_third">
						<h3 class="headg"> You pack it! We Pick and Ship your Products!!</h3>
						</div>
						<div class="col_one_third col_last">
						<a href="<?php echo base_url() ?>BecomeASeller/about#enquirynow"><button type="button" class="btn btn-primary btn-lg btn-block butnpric21">Become Merchant</button>
						</a>
						</div>
						
					</div>
				</div>

		</section><!-- #content end -->