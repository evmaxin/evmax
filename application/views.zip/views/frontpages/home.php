
		<div class="container">
			<div class="banner-slider5 simple-owl-slider">
				<div class="wrap-item" data-navigation="true" data-pagination="false" data-itemscustom="[[0,1]]">
					<div class="item-banner5">
						<div class="banner-thumb">
							<a href="#"><img src="<?php echo base_url() ?>assets/frontend/images/custom_sliders/3.jpg" alt="" /></a>
						</div>
						<div class="banner-info">
							<h3>happy new year 2016</h3>
							<h2>exta 45% off </h2>
							<a href="#" class="shop-now">shop now</a>
						</div>
					</div>
					<div class="item-banner5">
						<div class="banner-thumb">
							<a href="#"><img src="<?php echo base_url() ?>assets/frontend/images/custom_sliders/4.png" alt="" /></a>
						</div>
						<div class="banner-info style2">
							<h3>spectacular</h3>
							<h2>exta 35% off </h2>
							<a href="#" class="shop-now">shop now</a>
						</div>
					</div>
				</div>
			</div>
			<!-- End Banner Slider -->
			
			<div class="cat-brand">
							
			<div class="box-category10 red-box clearfix">
				<div class="content-left-category-hover">
                                    <h2 class="title-box10"><a style="color:#fff;" href="<?php echo base_url() ?>category/Woomen_Fashion/13">Woomen fashion</a></h2>
					<ul class="list-category-hover">
                                            <?php //print_r($products);
                                            foreach($mencategory as $men) { ?>
                                            <li class="active2"><a href="<?php echo base_url() ?>category/<?php echo $men->category_name;?>/<?php echo $men->category_id;?>"><?php echo $men->category_name;?></a></li>
                                            <?php } ?>				
					</ul>
					
					<!-- End Category Sidebar Display -->
				</div>

                            
                            <div class="banner-slider">
					<div class="banner-cat-hover-thumb">
						<a href="#"><img alt="" src="<?php echo base_url() ?>assets/frontend/images/custom_sliders/8.jpg"></a>
					</div>
					<div class="banner-cat-hover-info">
						<h3>Womens</h3>
						<h2>Fashion</h2>
						<a class="shopnow" href="#">shop now</a>
					</div>
				</div>
                          
                            <!-- End Category banner Display -->
                            
			



			</div>
			
			
			<!-- Box Category 10 -->
                        </div>
                        <!-- end category display -->
                        <div class="privacy-shipping privacy-shipping15">
				<div class="row">
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="item-privacy-shipping">
							<ul>
								<li><i class="fa fa-usd"></i></li>
								<li>
									<h2>30 DAYS RETURN</h2>
									<span>money back</span>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="item-privacy-shipping">
							<ul>
								<li><i class="fa fa-truck"></i></li>
								<li>
									<h2>FREE SHIPPING</h2>
									<span>on all orders over $99</span>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="item-privacy-shipping">
							<ul>
								<li><i class="fa fa-database"></i></li>
								<li>
									<h2>LOWEST PRICE</h2>
									<span>guarantee</span>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 col-xs-12">
						<div class="item-privacy-shipping">
							<ul>
								<li><i class="fa fa-hand-o-right"></i></li>
								<li>
									<h2>SAFE SHOPPING</h2>
									<span>guarantee 100%</span>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End Pricing Ship -->
	</div>
	<!-- End Content -->
	

                                                                                                             
                                                            
