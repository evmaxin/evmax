		<footer id="footer" style="background-color: #F5F5F5;border-top: 2px solid rgba(0,0,0,0.06);">

			<div class="container" style="border-bottom: 1px solid rgba(0,0,0,0.06);">

				<!-- Footer Widgets
				============================================= -->
				<div class="footer-widgets-wrap clearfix">

					<div class="col_two_third abt09">

						<div class="widget clearfix">

							<div class="row">

								<div class="col-lg-3 col-6 bottommargin-sm1 widget_links footrwid">
									<h3 class="widget-title">Coporate Address</h3>
									<ul>
										<li><span>Sai Teja Towers, <br> 503, 5th floor, Ajay Nagar Colony, <br> Bandlaguda, <br> Nagole, Hyderabad, <br> Telangana 500068. </span></li>
										
									</ul>
								</div>

								<div class="col-lg-3 col-6 bottommargin-sm1 widget_links">
									<h3 class="widget-title">Sell on evecosystem</h3>
									<ul>
								<li><a href="<?php echo base_url() ?>BecomeASeller/about">About evecosys </a></li>
              							<li><a href="<?php echo base_url() ?>BecomeASeller/advantages">Advantages</a></li>
              							<li><a href="<?php echo base_url() ?>BecomeASeller/howitworks">How It Works</a></li>
              							<li><a href="<?php echo base_url() ?>BecomeASeller/pricing">Pricing </a></li>
              							<li><a href="<?php echo base_url() ?>BecomeASeller/shippinganddelivery">Shipping and Delivery </a></li>
										
									</ul>
								</div>

								<div class="col-lg-3 col-6 bottommargin-sm1 widget_links">
									<h3 class="widget-title">Sell on evecosystem</h3>
									<ul>
										<li><a href="<?php echo base_url() ?>BecomeASeller/advertise">Advertise </a></li>
										<li><a href="<?php echo base_url() ?>BecomeASeller/support">Expert Support Partners</a></li>
										<li><a href="#">Management Team </a></li>
										<li><a href="<?php echo base_url() ?>merchant/login">Merchant Websys Login </a></li>
									</ul>
								</div>

								<div class="col-lg-3 col-6 bottommargin-sm1 widget_links">
									<h3 class="widget-title">Terms & Conditions</h3>
									<ul>
										
										<li><a href="#">Evecosystem marketplace policy</a></li>
              							<li><a href="#">Terms of use</a></li>
              							<li><a href="#">Privacy Policy</a></li>
									</ul>
								</div>

							</div>

						</div>

					</div>

					<div class="col_one_third col_last respfootr0">

						<div class="widget clear-bottommargin-sm clearfix">

							<div class="row">

								<div class="col-lg-12 bottommargin-sm">
									<div class="footer-big-contacts">
										<h3 class="widget-title">Contact</h3>
                                                                                <span><a href="<?php echo base_url() ?>" class="footrwid2"> evmax.in</a></span>
									</div>
								</div>

								<div class="col-lg-12 bottommargin-sm">
									<div class="footer-big-contacts">
										<span>Call Us:</span>
										<div class="footrwid3">+91 9205-991-992</div>
									</div>
								</div>

								<div class="col-lg-12 bottommargin-sm">
									<div class="footer-big-contacts">
										<span>Send an Email:</span>
										<div class="footrwid3">info@evmax.in</div>
									</div>
								</div>

							</div>

						</div>

					</div>

					<div class="col_one_third col_last respfootr0">

						<div class="widget clear-bottommargin-sm clearfix">

							<div class="row">

								<div class="col-lg-12 bottommargin-sm">
									<div class="footer-big-contacts">
										<h3 class="widget-title">Follow Us On</h3>
										<a href="https://www.facebook.com/ev.max.338" target="_blank" class="social-icon si-colored si-facebook">
											<i class="icon-facebook"></i>
											<i class="icon-facebook"></i>
										</a>
										<a href="https://twitter.com/evmax6" target="_blank" class="social-icon si-colored si-twitter">
											<i class="icon-twitter"></i>
											<i class="icon-twitter"></i>
										</a>
										<a href="https://plus.google.com/" target="_blank" class="social-icon si-colored si-gplus">
											<i class="icon-gplus"></i>
											<i class="icon-gplus"></i>
										</a>
									</div>
								</div>

								<div class="col-lg-12 bottommargin-sm12">
									<div class="footer-big-contacts">
										<span class="footrwid311">Download evmax app </span>
										<a href="#" class="social-icon si-colored si-android">
											<i class="icon-android"></i>
											<i class="icon-android"></i>
										</a>
										<a href="#" class="social-icon si-colored si-appstore">
											<i class="icon-appstore"></i>
											<i class="icon-appstore"></i>
										</a>
									</div>
								</div>

								

							</div>

						</div>

					</div>

				</div><!-- .footer-widgets-wrap end -->
 <p style="clear: both;"><b>DISCLAIMER:</b> Product Names, Logos, Brands and other Trademarks featured or referred to
within the evmax.in website are the property of their respective trademark holders. These
trademarks are not affiliated with evmax.in. They do not sponsor or endorse our website,
materials or services.</p>
			</div>

			<!-- Copyrights
			============================================= -->
			<div id="copyrights">

				<div class="container center uppercase clearfix">

					<p class="footrwid1">Copyrights © 2018 All Rights Reserved.</p>

				</div>

			</div>

	</footer><!-- #footer end -->

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	<!-- External JavaScripts
	============================================= -->
	<script src="<?php echo base_url() ?>assets/layout2/js/jquery.js"></script>
	<script src="<?php echo base_url() ?>assets/layout2/js/plugins.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script src="<?php echo base_url() ?>assets/layout2/js/functions.js"></script>
        <script>

  $(document).ready(function(){
  $("#enquiryButton").click(function(){
        $("#dailog-box").css("display","block");
       $("html").css({"overflow-y": "hidden"});
    //$(".box").css({"overflow": "scroll"});
            
  });
     $(".close").click(function(){
     $("html").css({"overflow-y": "scroll"});
            
    $("#dailog-box").css("display","none");
            
  });
  
  
  $("#submit").on("click",function(e){
       
  //check for duplicate email

    if (($("input[name*='categories']:checked").length)<=0) {
        alert("You must check at least 1 category");
    return false
    }
    return true;
    
       
  
    });     
          
  
  });
  function search_func(value,type) {
      
      if (value.length >= 3 ) {
          $.ajax({
                 type: "POST",
                data: {
                    value: value,
                    type: type
                },
                url: "<?php echo base_url(); ?>index.php/Ajax/checkForDuplicate",
                success: function(data)
                {
                    if(data === 'EMAIL_EXISTS')
                    {
                     $('.user')
                            .css('color', 'red')
                            .html("This email already exists!");
                    $('#submit').prop('disabled', true);
                    return false;
                     }
                     else if(data === 'MOBILE_EXISTS')
                    {
                       // alert();
                     $('.user')
                            .css('color', 'red')
                            .html("This mobile already exists!");
                    $('#submit').prop('disabled', true);
                    return false;
                     }
                    else
                    {
                      $('#submit').prop('disabled', false);
                      $('.user').css('color', '#f5f5f5').html("");
                    }
                   // if(data === 'EMAIL_NOT_EXISTS')
                }
            }); 
            }
  }
  </script>

</body>
</html>