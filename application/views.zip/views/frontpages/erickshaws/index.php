
<style>
.desk {
       font-size: 16px !important;
       padding-left: 22px;
    padding-right: 13px;
    }
@media only screen and (max-width: 375px) {
    .desk {
       font-size: 13px !important;
       padding-left: 0px;
    padding-right: 0px;
    }
}
@media only screen and (max-width: 768px) {
    .desk {
       font-size: 13px !important;
       padding-left: 0px;
    padding-right: 0px;
    }
}
.feature-box.fbox-plain .fbox-icon i {
    font-size: 27px;
      color: #57b952 !important;
}
.feature-box h5{
    font-size: 13px !important;
    color: #3051a0;
    padding-top: 6px;

  }
.topmargin {
    margin-top: 29px !important;
}
label{
color: #fff;
}
.topmargin {
    margin-top: 29px !important;
}
.feature-box h5 {
    font-size: 12px;
    color: #3051a0;
}
.lft1DD{
  float: left !important;
      margin-right: 7%;
}
.heading-block {
    margin-bottom: 29px !important;
}
.Shh1{
      margin-bottom: 20px !important;
}
.feature-box.fbox-plain.fbox-small {
    padding-left: 17px;
    padding-bottom: 23px;
}
.Shh2{
  padding-bottom: 13px;
    position: relative;
    left: -14px;
}
.Shh3{
  color:#3051a0 !important; 
}
.Shh4{
      line-height: 25px;
}
.form-control {
    display: block;
    width: 100%;
    padding: 0.375rem 0.75rem;
    font-size: 12px !important;
    line-height: 1.5;
}
.form-control {
    border-radius: 3px;
        height: 30px !important;
}
.btn {
    font-size: 12px;
    color: #57b952;
    font-weight: 500;
}
.form-group {
    margin-bottom: 5px;
}
@media only screen and (min-width: 1200px){
.myenqc1 {
    font-size: 16px !important;
}
}
</style>

	

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		<!--<div id="top-bar">

                    <div class="container clearfix">
                        
                        <h2 class="nott t500 divcenter  center" style="color: #fff;">e-Rickshaw factory</h2>
                    </div>
                                                </div>-->

<section>
    <map name="workmap">
  			
  			<area shape="rect" coords="1400,10,20,200" href="<?php echo base_url() ?>">
                       
  			
		</map>
    <?php 
if(isset($sliderImages)) { 
    $k=0;
  foreach ($sliderImages as $img) {
         if($img->slider_category_id==18){ ?>
    <a target="<?php echo $img->link_url?'_blank':'';?>" href="<?php echo $img->link_url?$img->link_url:'#';?>"><img src="<?php echo base_url() ?>public/uploads/admin/sliders/<?php echo $img->name;?>" class="img-responsive"></a>
            
            <?php $k++;} if($k==1){break;} } }?>
		
		</section>
                <section>
			<div class="col-lg-12 col-md-6 col-sm-12">
                               <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
           <h4 class="modal-title">Send Email to info@evmax.in</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
       
      </div>
      <div class="modal-body">
          <p>Please send below details to <b><a href="mailto:info@evmax.in?Subject=Erickshaw%20Details&body=Manufacturer Logo%20%3A%0D%0ABrand Logo%20%3A%0D%0ABrand Banner%20%3A%0D%0ACompany Name%20%3A%0D%0ACity %20%3A%0D%0AState%20%3A%0D%0ACountry%20%3A%0D%0AContact person phone number%20%3A%0D%0A" target="_top">info@evmax.in</a> </b> or  <a href="mailto:info@evmax.in?Subject=Erickshaw%20Details&body=Manufacturer Logo%20%3A%0D%0ABrand Logo%20%3A%0D%0ABrand Banner%20%3A%0D%0ACompany Name%20%3A%0D%0ACity %20%3A%0D%0AState%20%3A%0D%0ACountry%20%3A%0D%0AContact person phone number%20%3A%0D%0A" target="_top">Click here</a></p>
        <p>Manufacturer Logo<br> Brand Logo <br>Brand Banner <br>Company Name <br>City <br>State<br> Country <br>Contact person phone number</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

<div id="msg2" class="">
             <?php if(isset($_REQUEST['q'])&&($_REQUEST['q']==="success")){ ?>
    <div class="alert alert-success alert-dismissable" style="text-align: center;top: 10px;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
               <?php  echo $_REQUEST['msg'];?>
          </div>
          <?php } ?>
      </div>
               <marquee id='scroll_news'>
                <div onMouseOver="document.getElementById('scroll_news').stop();" onMouseOut="document.getElementById('scroll_news').start();" style="position: relative;top: 4px;padding: 2px 0px;"><a data-toggle="modal" data-target="#myModal" href="#" style="color: #3051a0;font-size: 18px;    font-weight: 800;">List your e-Rickshaw on evmax "e-Rickshaw factory club"  Today</a></div></marquee>
                
               <!-- <span><a href="<?=base_url();?>erickshaw#requiredfields" >click here</a></span>-->
            </div>
                    
		</section>

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="container clearfix">
                            
				
					<div class="row clearfix">
                                            
                                            
                                            <span id="part1"></span>
						<div class="col-lg-4 col-md-6 topmargin bottommargin-sm">
                                                    <h3 style="color: #3051a0;">Benefits to Manufacturers</h3>
							<div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
								<img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>Easy to find dealer leads.</h5>
								
							</div>
                                                    <div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>Excusive webpage to list only e-Rickshaws.</h5>
								
							</div>
                                                    <div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>E-Catalogue design support.</h5>
								
							</div>
                                                    <div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>Link brand image to your website.</h5>
								
							</div>
                                                    <div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>Super ad banner and ad box advertisements to attract dealers and customers.</h5>
								
							</div>
                                                    <div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>Buyer can easily find out e-Rickshaws on one webpage and download e-catalogue.</h5>
								
							</div>
                                                    <div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>Mechanics support from listed evmaxev mechanics.</h5>
								
							</div>
                                                    <div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>Battery Swapping partner support.</h5>
								
							</div>
                                                    <div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>Charging Station Partner support.</h5>
								
							</div>
                                                    <div class="feature-box fbox-plain topmargin">
								<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
								<h5>You can offer special promotions to attract customers.</h5>
								
							</div>

							

						
						</div>
                                           
                                            <div class="col-lg-2 col-md-2 d-md-none d-lg-block " ></div>
						<div class="col-lg-6 col-md-6 topmargin bottommargin-sm" >
									
                                                    <div class="heading-block">
                                                        <h3> <span style="color: #3051a0;">How It Works </span></h3>
                                                        <p class="Shh1">5 easy Steps to list your e-Rickshaw on evmax – e-Rickshaw Factory</p>
                                                      <div class="">
                                                          <div class="feature-box fbox-small fbox-plain fbox-dark" >
							<div class="fbox-icon">
								<a href="#"><i class="icon-tags"></i></a>
							</div>
                                                               <span id="requiredfields"></span>
                                                              <div id="nav1">
							<h5 class="Shh2">List your e-Rickshaw details here</h5>
	<form action="<?php echo base_url() ?>ERickshaws/add" method="post" enctype="multipart/form-data" id="addproduct">
            <div class="row" style="background: #005387;">
            <div class="col-lg-6 col-md-6 topmargin bottommargin-sm" >
 <div class="form-group">
                  <label class="control-label">Company Name:</label>
                  <input type="text" name="company_name" required id="company_name" class="form-control">
                                                

                </div>
  <div class="form-group">
                  <label class="control-label">City</label>
                  <input type="text" name="city" id="city" required class="form-control">
                                                

                </div>
  <div class="form-group">
                                                    
                                                    <label class="control-label">State</label>
                                                   <select name="state_id" id="state_id" class="form-control" required="required">
                                                        <option value="">Select</option>
                                                                                                                 <?php
                                if (isset($states) && (count($states) > 0)) {

                                    foreach ($states as $state) {
                                        ?>

                                        <option value="<?php echo $state->state_name ? $state->state_name : ''; ?>"><?php echo $state->state_name ? $state->state_name : ''; ?></option>
    <?php }
} ?>

                                  
                                                    </select>

                                                </div>
   <div class="form-group">
                  <label class="control-label">Country</label>
                  <input type="text" name="country" id="country" class="form-control" required>
                                                

                </div>
     <div class="form-group">
                  <label class="control-label">Contact Number</label>
                  
                  <input type="text" name="contact_number" id="contact_number" class="form-control" maxlength="12" minlength="10" required>
                                                

                </div>
            </div>
            
            <div class="col-lg-6 col-md-6 topmargin bottommargin-sm" >
    <div class="form-group">
                  <label class="control-label">Website Link</label>
                  <input type="text" name="url" id="url" class="form-control">
                                                

                </div>
 <div class="form-group">
                      <label class="control-label">Company Logo <span class="required"> * </span> <a href="#" data-toggle="tooltip" title="Please select image for Manufacturer Logo"><i class='glyphicon glyphicon-info-sign'></i></a></label>
                        <input type="file" name="userfile[]" id="userfile" required class="form-control" accept="image/jpg, image/jpeg,image/png, image/gif"/>
                        
                        </div>
 <div class="form-group">
                      <label class="control-label">Brand Logo <span class="required"> * </span> <a href="#" data-toggle="tooltip" title="Please select image for Brand Logo"><i class='glyphicon glyphicon-info-sign'></i></a></label>
                        <input type="file" name="userfile[]" required id="brandlogo" class="form-control" accept="image/jpg, image/jpeg,image/png, image/gif"/>
                        
                        </div>
    <div class="form-group">
                      <label class="control-label">Brand Banner <span class="required"> * </span> <a href="#" data-toggle="tooltip" title="Please select image for Brand Banner"><i class='glyphicon glyphicon-info-sign'></i></a></label>
                        <input type="file" name="userfile[]" required id="brandbanner" class="form-control" accept="image/jpg, image/jpeg,image/png, image/gif"/>
                     
                        </div>
                                                         <div class="form-group">
                      <label class="control-label">E Catalog <a href="#" data-toggle="tooltip" title="Please select pdf for E Catalog"><i class='glyphicon glyphicon-info-sign'></i></a></label>
                        <input type="file" name="userfile[]" id="brandbanner" class="form-control" accept="application/pdf"/>
                        
                        </div>
            </div>
                <div class="form-actions" style="padding: 0px 15px;top: -7px;position: relative;"> 
                      <input type="submit"  class="btn blue" name="submit" value="Submit"/>
                     
                    
                </div>
            </div>

        </form>
                                                              </div>
						</div>
					</div> 
                                                        
                                                                <div class="">
						<div class="feature-box fbox-small fbox-plain fbox-dark">
							<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
							<h5>Evmax support team uploads your details on “e-Rickshaw Buyers webpage”.</h5>
							
						</div>
					</div> 
                                                                <div class="">
						<div class="feature-box fbox-small fbox-plain fbox-dark">
							<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
							<h5>Support team will inform you once it is uploaded.</h5>
							
						</div>
					</div>
                                                                      <div class="">
						<div class="feature-box fbox-small fbox-plain fbox-dark">
							<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
							<h5>Buyer visits evmax e-Rickshaw webpage and clicks on your image to reach your website.</h5>
							
						</div>
					</div>
                                                                              <div class="">
						<div class="feature-box fbox-small fbox-plain fbox-dark">
							<div class="fbox-icon lft1DD">
                <img src="<?php echo base_url() ?>assets/frontend/img/iconsbuyers/tags.png" class="icn2A">
							</div>
							<h5>Buyer will call you on listed contact number directly to book e-Rickshaw.</h5>
							
						</div>
					</div>
						</div>

						</div>
                                            <h2 class="myenqc1 Shh4"><a href="<?php echo base_url() ?>BecomeASeller/support" class="Shh3">Evmax Expert Support Partners</a> will help you to design attractive e-Catalogue and web ad design for very competitive prices. Call +91 9205 991 992 to get more information.</h2>
						
					</div>

			</div> <!-- Features Area End -->


		</section><!-- #content end -->
<section>
			<img src="<?php echo base_url() ?>assets/layout2/images/offers.png" class="img-responsive">
		</section>
	