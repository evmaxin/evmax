

<html>
<head>
<title></title>
<script src="//code.jquery.com/jquery-1.11.2.min.js"></script>

 <link rel="stylesheet" href="http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.css" />	

 <script src="http://cdn.leafletjs.com/leaflet-0.7.3/leaflet.js"></script>
</head>
<body>

<?php echo $map['html']; ?>
 <?php echo $map['js']; ?>
</body>
</html>